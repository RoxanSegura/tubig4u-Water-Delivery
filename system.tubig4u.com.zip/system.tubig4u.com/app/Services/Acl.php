<?php 

namespace App\Services;
use Auth;
use App\Models\User; 
use App\Models\Order;  
use App\Repositories\ResourceRepository;

class Acl {  
  
    protected $order,$orders,$processing;  

    function __construct(Order $order,Request $request)
    { 
        $this->order = new ResourceRepository($order);  
    	$this->request = $request;  
    }

	public static function navigation()
	{  
		$type = Auth::user()->accountType;
        // dd($type);
		$nav = [ 
			'admin' => [
				[ 
					'title'   => '[F1] Dashboard',
					'active'  => 'dashboard',
					'url'     => 'app.dashboard',
					'icon'    => 'dashboard'
				],
				[ 
					'title'   => '[F2] Branches',
					'active'  => 'branch',
					'url'     => 'app.branch',
					'icon'    => 'home'
				], 
				[ 
					'title'   => '[F3] Products',
					'active'  => 'product',
					'url'     => 'app.product',
					'icon'    => 'opacity'
				], 
				[ 
					'title'   => '[F4] Reports',
					'active'  => 'report',
					'url'     => 'app.report',
					'icon'    => 'show_chart'
				], 
			],
			'branch' => [
				[ 
					'title'   => '[F1] Dashboard',
					'active'  => 'dashboard',
					'url'     => 'app.dashboard',
					'icon'    => 'dashboard'
				],
				[ 
					'title'   => '[F2] Customers',
					'active'  => 'customers',
					'url'     => 'app.customers',
					'icon'    => 'perm_identity'
				],
				[ 
					'title'   => '[F3] Delivery Boy',
					'active'  => 'drivers',
					'url'     => 'app.drivers',
					'icon'    => 'people_outline'
				],
				[ 
					'title'   => '[F4] Orders',
					'active'  => 'orders',
					'url'     => 'app.orders',
					'icon'    => 'view_column',
					'notif'   => Order::where(function($query){
									$query->orWhere('orderStatus','=','pending');
									$query->orWhere('orderStatus','=','request'); 
								})->whereBranch_id(Auth::user()->id)
								  ->whereStatus(1)
								  ->count() 
				],
				[ 
					'title'   => '[F5] Processing',
					'active'  => 'orders.processing',
					'url'     => 'app.orders.processing',
					'icon'    => 'add_shopping_cart',
					'notif'   => Order::where(function($query){
									$query->orWhere('orderStatus','=','pickup');
									$query->orWhere('orderStatus','=','redeliver');
									$query->orWhere('orderStatus','=','collection'); 
								})->whereBranch_id(Auth::user()->id)
								  ->whereStatus(1)
								  ->count() 
				], 
				[ 
					'title'   => '[F4] Reports',
					'active'  => 'report',
					'url'     => 'app.report',
					'icon'    => 'show_chart'
				], 
				// , 
				// [ 
				// 	'title'   => '[F6] For Collection',
				// 	'active'  => 'orders.collection',
				// 	'url'     => 'app.orders.collection',
				// 	'icon'    => 'notifications' 
				// ],
			],
			'driver' => [
				[ 
					'title'   => '[F1] Dashboard',
					'active'  => 'dashboard',
					'url'     => 'app.dashboard',
					'icon'    => 'dashboard'
				],
				[ 
					'title'   => '[F2] Orders',
					'active'  => 'driver.open',
					'url'     => 'app.driver.open',
					'icon'    => 'view_column',
					'notif'   => Order::where(function($query){
									$query->orWhere('orderStatus','=','pickup');
									$query->orWhere('orderStatus','=','redeliver');
									$query->orWhere('orderStatus','=','collection'); 
								})->whereDriver_id(Auth::user()->id)
								  ->whereStatus(1)
								  ->count() 
				] , 
				[ 
					'title'   => '[F4] Reports',
					'active'  => 'report',
					'url'     => 'app.report',
					'icon'    => 'show_chart'
				], 
			]
		];

		return $nav[$type];
	} 

	public static function create($module)
	{ 
		$type = Auth::user()->accountType;

		$rules = [
			'admin' => ['addButton'],
			'branch' => ['addButton'],
			'driver' => [],
		];

		return (in_array($module, $rules[$type])) ? true : false;

	}
}