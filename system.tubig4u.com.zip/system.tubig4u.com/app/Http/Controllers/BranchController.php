<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User;  
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon;
use App\Repositories\ResourceRepository;

class BranchController extends Controller
{
	protected $user; 
    protected $request;

    function __construct(User $user,Request $request)
    {
        $this->user = new ResourceRepository($user); 
    	$this->request = $request; 
    }

    public function index()
    {  
        return view('pages.branch.index')
            ->with([
                'title' => 'Branches',
                'active' => 'branch',
                'sub' => 'List', 
                'data' => $this->user->getAll(['accountType' => 'branch', 'status' => 1])
            ]);
    }

    public function add()
    {  
        return view('pages.branch.add')
            ->with([
                'title' => 'Branches',
                'active' => 'branch',
                'sub' => 'Add new' 
            ]);
    }

    public function addSave()
    {
        $res = $this->user->create([
            'name' => $this->request->name,
            'username' => $this->request->username,
            'password' => Hash::make($this->request->password),
            'contact' => $this->request->contact,
            'address' => $this->request->address, 
            'accountType' => 'branch',
            'status' => 1,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('New branch has been saved !');
    }

    public function update($id)
    {  
        $data = $this->user->getById($id);

        if (!$data) {
            return Redirect::route('app.branch');
        }

        return view('pages.branch.update')
            ->with([
                'title' => 'Branches',
                'active' => 'branch',
                'sub' => 'Update',
                'data' => $data
            ]);
    }

    public function updateSave($id)
    {
        $params = [
            'name' => $this->request->name,
            'username' => $this->request->username, 
            'contact' => $this->request->contact,
            'address' => $this->request->address, 
        ];

        if ($this->request->has('password')) {
            $params['password'] = Hash::make($this->request->password);
        }

        $res = $this->user->update($id,$params);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Branch has been saved !');
    }

    public function delete($id)
    {
        $res = $this->user->update($id,[ 
            'status' => 0,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Branch has been deleted !');
    }
 
}




