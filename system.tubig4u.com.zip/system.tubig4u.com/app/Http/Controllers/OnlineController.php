<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User;  
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon,DB;
use App\Repositories\ResourceRepository;

class OnlineController extends Controller
{
	protected $user; 
    protected $request;

    function __construct(User $user,Request $request)
    {
        $this->user = new ResourceRepository($user); 
    	$this->request = $request; 
    }

    public function index()
    {  
        $id = $this->request->user_id;
        $time = (Carbon::now('Asia/Manila'));

        $update = $this->user->update($id,[
            'online' => $time
        ]);

        return response()->json($update);
    } 

    public function branch()
    { 

        // $dasta = User::whereStatus(1)->whereBranch_id($this->request->branch_id)->where('online','>',NOW() - INTERVAL 15 MINUTE);
        $data = DB::select('SELECT * FROM users where branch_id="'.$this->request->branch_id.'" and status="1" and online > NOW() - INTERVAL 1 MINUTE');
        return response()->json($data);
    }
}





