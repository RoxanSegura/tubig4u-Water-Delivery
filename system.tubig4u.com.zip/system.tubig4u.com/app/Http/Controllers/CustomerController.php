<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User;  
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon;
use App\Repositories\ResourceRepository;

class CustomerController extends Controller
{
	protected $user; 
    protected $request;

    function __construct(User $user,Request $request)
    {
        $this->user = new ResourceRepository($user); 
    	$this->request = $request; 
    }

    public function index()
    {  
        return view('pages.customers.index')
            ->with([
                'title' => 'Customers',
                'active' => 'customers',
                'sub' => 'Lists', 
                'data' => $this->user->getAll(['accountType' => 'customer', 'status' => 1,'branch_id' => Auth::user()->id])
            ]);
    }

    public function add()
    {  
        return view('pages.customers.add')
            ->with([
                'title' => 'Customers',
                'active' => 'customers',
                'sub' => 'Add new' 
            ]);
    }

    public function addSave()
    {
        $name = $this->request->has('name') ? $this->request->name : null;
        $contact = $this->request->has('contact') ? $this->request->contact : null;

        $res = $this->user->create([
            'name' => $name, 
            'contact' => $contact,
            'address' => $this->request->address,
            'accountType' => 'customer',
            'branch_id' => Auth::user()->id,
            'status' => 1,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('New customer has been saved !');
    }

    public function update($id)
    {  
        $data = $this->user->getById($id);

        if (!$data) {
            return Redirect::route('app.customers');
        }

        return view('pages.customers.update')
            ->with([
                'title' => 'Customers',
                'active' => 'customers',
                'sub' => 'Update',
                'data' => $data
            ]);
    }

    public function updateSave($id)
    {
        $res = $this->user->update($id,[
            'name' => $this->request->name, 
            'contact' => $this->request->contact,
            'address' => $this->request->address 
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Customer has been saved !');
    }

    public function delete($id)
    {
        $res = $this->user->update($id,[ 
            'status' => 0,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Customer has been deleted !');
    }
 
}




