<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User;  
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon;
use App\Repositories\ResourceRepository;

class DriverController extends Controller
{
	protected $user; 
    protected $request;

    function __construct(User $user,Request $request)
    {
        $this->user = new ResourceRepository($user); 
    	$this->request = $request; 
    }

    public function index()
    {  
        return view('pages.driver.index')
            ->with([
                'title' => 'Driver',
                'active' => 'drivers',
                'sub' => 'List', 
                'data' => $this->user->getAll(['accountType' => 'driver', 'status' => 1,'branch_id' => Auth::user()->id])
            ]);
    }

    public function add()
    {  
        return view('pages.driver.add')
            ->with([
                'title' => 'Driver',
                'active' => 'drivers',
                'sub' => 'Add new' 
            ]);
    }

    public function addSave()
    {
        $res = $this->user->create([
            'name' => $this->request->name,
            'username' => $this->request->username,
            'password' => Hash::make($this->request->password),
            'contact' => $this->request->contact,
            'address' => $this->request->address,
            'plateNumber' => $this->request->plateNumber,
            'accountType' => 'driver',
            'branch_id' => Auth::user()->id,
            'status' => 1,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('New driver has been saved !');
    }

    public function update($id)
    {  
        $data = $this->user->getById($id);

        if (!$data) {
            return Redirect::route('app.driver');
        }

        return view('pages.driver.update')
            ->with([
                'title' => 'Drivers',
                'active' => 'drivers',
                'sub' => 'Update',
                'data' => $data
            ]);
    }

    public function updateSave($id)
    {
        $params = [
            'name' => $this->request->name,
            'username' => $this->request->username, 
            'contact' => $this->request->contact,
            'address' => $this->request->address,
            'plateNumber' => $this->request->plateNumber,
        ];

        if ($this->request->has('password')) {
            $params['password'] = Hash::make($this->request->password);
        }

        $res = $this->user->update($id,$params);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Driver has been saved !');
    }

    public function delete($id)
    {
        $res = $this->user->update($id,[ 
            'status' => 0,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Driver has been deleted !');
    }
 
}




