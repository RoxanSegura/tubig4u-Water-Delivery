<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User;   
use App\Models\Product;  
use App\Models\Order;   
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon;
use App\Repositories\ResourceRepository;

class OrderController extends Controller
{
    protected $user; 
    protected $product; 
    protected $order; 
    protected $request;

    function __construct(User $user,Product $product,Order $order,Request $request)
    {
        $this->user = new ResourceRepository($user); 
        $this->order = new ResourceRepository($order); 
        $this->product = new ResourceRepository($product); 
    	$this->request = $request; 
    }

    public function index()
    {
        $drivers = User::where('accountType', 'driver')
            //->whereRaw('online > NOW() - INTERVAL 1 MINUTE')
            ->where('branch_id', Auth::user()->id)
            ->get();
        
        return view('pages.orders.index')
            ->with([
                'title' => 'Orders',
                'active' => 'orders',
                'sub' => 'Board',
                'drivers' => $drivers,
                'pending' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'pending','branch_id' => Auth::user()->id]), 
                'ready' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'ready', 'branch_id' => Auth::user()->id]), 
                'request' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'request','branch_id' => Auth::user()->id])
            ]);
    } 

    public function collectionOrders()
    {
        return view('pages.orders.collection')
            ->with([
                'title' => 'For Collection Orders',
                'active' => 'orders.collection',
                'sub' => 'Board',
                'collection' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'collection','branch_id' => Auth::user()->id])
            ]);   
    }

    public function processingOrders()
    {
        $drivers = User::where('accountType', 'driver')
//            ->whereRaw('online > NOW() - INTERVAL 1 MINUTE')
            ->where('branch_id', Auth::user()->id)
            ->get();
        
        return view('pages.orders.processing')
            ->with([
                'title' => 'Processing Orders',
                'active' => 'orders.processing',
                'sub' => 'Board',
                'drivers' => $drivers,
                'pending' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'pickup','branch_id' => Auth::user()->id]),  
                'redeliver' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'redeliver','branch_id' => Auth::user()->id]),
                'collection' => $this->order->orderBy('updated_at', 'desc')->getAll(['orderStatus' => 'collection','branch_id' => Auth::user()->id])
            ]);   
    }

    public function driverOpen()
    { 
        $userId = Auth::user()->id;
        return view('pages.orders.driver.open')
            ->with([
                'title' => 'Orders',
                'active' => 'driver.open',
                'sub' => 'Board', 
                'ready'       => $this->order->getAll(['orderStatus' => 'ready','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id]), 
                'ondelivery'  => $this->order->getAll(['orderStatus' => 'pickup','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id]), 
                'redeliver'   => $this->order->getAll(['orderStatus' => 'redeliver','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id]),
                'collection'  => $this->order->getAll(['orderStatus' => 'collection','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id]),
            ]);
    }

    public function driverDeliveries()
    { 
        $userId = Auth::user()->id;
        return view('pages.orders.driver.deliveries')
            ->with([
                'title' => 'Orders',
                'active' => 'driver.deliveries',
                'sub' => 'Board', 
                'pending' => $this->order->getAll(['orderStatus' => 'pickup','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id]), 
                'redeliver' => $this->order->getAll(['orderStatus' => 'redeliver','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id])
            ]);
    }

    public function driverCollection()
    { 
        $userId = Auth::user()->id;
        return view('pages.orders.driver.collection')
            ->with([
                'title' => 'Orders',
                'active' => 'driver.collection',
                'sub' => 'Board', 
                'collection' => $this->order->getAll(['orderStatus' => 'collection','driver_id' => Auth::user()->id, 'branch_id' => Auth::user()->branch_id])
            ]);
    }

    public function add()
    {  
        return view('pages.orders.add')
            ->with([
                'title' => 'Add Orders',
                'active' => 'orders',
                'sub' => 'Add Orders',
                'drivers' => $this->user->getAll(['accountType' => 'driver', 'status' => 1,'branch_id' => Auth::user()->id]),
                'customers' => $this->user->getAll(['accountType' => 'customer', 'status' => 1,'branch_id' => Auth::user()->id ]),
                'products' => $this->product->getAll(['status' => 1]), 
            ]);
    } 

    public function summary($id)
    {
        return view('pages.invoice.index')
            ->with([
                'title' => 'Order Summary',
                'active' => 'orders',
                'sub' => 'Order Summary', 
                'data' => $this->order->getById($id), 
            ]);
    }

    public function summaryUpdate($id)
    {
        return view('pages.invoice.update')
            ->with([
                'title' => 'Update Order',
                'active' => 'orders',
                'sub' => 'Order Summary', 
                'data' => $this->order->getById($id), 
            ]);
    }


    public function addSave()
    {
        $customer = $this->request->customer;
        $orders = [];

        foreach ($this->request->post() as $key => $value) {
            if (is_numeric($key) && $value != 0) {
                array_push($orders, [
                    'id' => $key,
                    'name' => $this->product->getById($key)->name,
                    'price' => $this->product->getById($key)->price,
                    'qty' => $value,
                    'total' => ($value * $this->product->getById($key)->price)
                ]);
            }
        }

        if (count($orders) <= 0) {
            return back()->withError('Please add an item on this order !');
        }

        $refNo = strtoupper(substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil(5/strlen($x)) )),1,5));
        $res = $this->order->create([
            'refNo' => $refNo,
            'customer_id' => $customer,
            'orders' => json_encode($orders),
            'orderStatus' => 'pending',
            'branch_id' => Auth::user()->id,
            'driver_id' => $this->request->delivery,
            'status' => 1
        ]);

        if (!$res) {
            return back()->withError('Please add an item on this order !');
        }


        return Redirect::route('app.orders');

    }

    public function move($id)
    {
        /*$this->order->update($id,[
            'orderStatus' => 'ready'
            ]);*/

        if (!\Request::has('driver')) {
            if (\Request::has('prev_url')) {
                return redirect(\Request::get('prev_url'))->withError('Please select a delivery boy!');
            }
            
            return back()->withError('Please select a delivery boy!');
        }
        
        $driver = \Request::get('driver');

        $driverData = User::where('id', $driver)
            ->where('accountType', 'driver')
            ->whereRaw('online > NOW() - INTERVAL 1 MINUTE')
            ->where('branch_id', Auth::user()->id)
            ->first();

        if (empty($driverData)) {
            if (\Request::has('prev_url')) {
                return redirect(\Request::get('prev_url'))->withError('Invalid delivery boy selected');
            }
            
            return back()->withError('Invalid delivery boy selected !');
        }
        
        $this->order->update($id, [
            'orderStatus' => 'pickup',
            'driver_id' => $driver
        ]);

        
        if (\Request::has('prev_url')) {
            return redirect(\Request::get('prev_url'));
        }
        
        return back();
    }

    public function pickup($id)
    {
        $this->order->update($id,[
            'orderStatus' => 'pickup'
        ]);

        return back();
    }

    public function redeliver($id)
    {
        $this->order->update($id,[
            'orderStatus' => 'redeliver'
        ]);

        return back();
    }

    public function delete($id)
    {
        $this->order->delete($id);

        return back();
    }

    public function accept($id)
    {
        $this->order->update($id,[
            'orderStatus' => 'pickup'
        ]);

        return back();
    }

    public function decline($id)
    {
        $this->order->update($id,[
            'driver_id' => null,
            'orderStatus' => 'ready'
        ]);

        return back();
    }

    public function driverCancel($id)
    {
        $this->order->update($id,[
            'driver_id' => null,
            'orderStatus' => 'ready'
        ]);

        return back();
    }

    public function reopen($id)
    {
        $this->order->update($id,[
            'driver_id' => null,
            'orderStatus' => 'ready'
        ]);

        return back();
    }

    public function driverAccept($id)
    { 
        $this->order->update($id,[
            'driver_id' => Auth::user()->id,
            'orderStatus' => 'request'
        ]);

        return back();
    }

    public function summaryUpdateSave($id)
    {
        $this->order->update($id,[ 
            'orderStatus' => $this->request->status
        ]);

        return back();
    }

    public function driverDelivered($id)
    {
        $this->order->update($id,[ 
            'orderStatus' => 'delivered'
        ]);

        return back();
    }

    public function driverUpdateStatus($id,$status)
    { 
        $this->order->update($id,[ 
            'orderStatus' => $status
        ]);

        if (\Request::has('prev_url')) {
            return redirect(\Request::get('prev_url'));
        }
        
        return back();
    }
}




