<?php

namespace App\Http\Controllers;
 
use Illuminate\Http\Request;  
use App\Models\Product;  
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon;
use App\Repositories\ResourceRepository;

class ProductController extends Controller
{
	protected $product; 
    protected $request;

    function __construct(Product $product,Request $request)
    {
        $this->product = new ResourceRepository($product); 
    	$this->request = $request; 
    }

    public function index()
    {  
        return view('pages.product.index')
            ->with([
                'title' => 'Products',
                'active' => 'product',
                'sub' => 'List', 
                'data' => $this->product->getAll(['status' => 1])
            ]);
    }

    public function add()
    {  
        return view('pages.product.add')
            ->with([
                'title' => 'Products',
                'active' => 'product',
                'sub' => 'Add new' 
            ]);
    }

    public function addSave()
    {

        $file = $this->request->file('img');
        $imgName = $file->getClientOriginalName(); 
        $file->move('public/img/product/',$file->getClientOriginalName());

        $res = $this->product->create([
            'name' => $this->request->name,
            'price' => $this->request->price,   
            'img' => $imgName,
            'status' => 1,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('New Product has been saved !');
    }

    public function update($id)
    {  
        $data = $this->product->getById($id);

        if (!$data) {
            return Redirect::route('app.product');
        }

        return view('pages.product.update')
            ->with([
                'title' => 'Products',
                'active' => 'product',
                'sub' => 'Update',
                'data' => $data
            ]);
    }

    public function updateSave($id)
    { 
        $params = [
            'name' => $this->request->name,
            'price' => $this->request->price,    
            'status' => 1,
        ];

        if ($this->request->hasFile('img')) {
            $file = $this->request->file('img');
            $imgName = $file->getClientOriginalName(); 
            $file->move('public/img/product/',$file->getClientOriginalName());
            $params['img'] = $imgName;
        }

        $res = $this->product->update($id,$params);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Product has been saved !');
    }

    public function delete($id)
    {
        $res = $this->product->update($id,[ 
            'status' => 0,
        ]);

        if(!$res){
            return back()->withError('Something went wrong !');
        }

        return back()->withSuccess('Product has been deleted !');
    }
 
}




