<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User; 
use Redirect,Requests,Hash,Validator,Auth;
use App\Repositories\ResourceRepository;

class AuthenticationController extends Controller
{
    protected $user; 
	protected $request;

    function __construct(User $user,Request $request)
    {
        $this->user = new ResourceRepository($user); 
    	$this->request = $request; 
    }
 
    public function index()
    { 
    	return view('pages.login.index')
    		->with([ 
    			'title' => 'Account Login'
    		]);
    }
    
    public function verify()
    {
        $validatData = $this->request->validate([
            'username' => 'required',
            'password' => 'required|min:1',
        ]);

        $credentials = [
            'username' => $this->request->username,
            'password' => $this->request->password,
            'status' => 1,
        ];
        
        if(Auth::attempt($credentials)){  
            return Redirect::route('app.dashboard')
                ->with([
                    "success" => "Welcome ".Auth::user()->name
                ]);
        }

    	return Redirect::route('app.login')
    		->with([  
    			'error'  => 'Invalid login credentials !'
    		]);
    }

    public function logout()
    {  
        Auth::logout();

        return Redirect::route('app.login');
    }
}