<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  
use App\Models\User; 
use App\Models\Order; 
use App\Models\Product; 
use Redirect,Requests,Hash,Validator,Auth,Carbon\Carbon;
use App\Repositories\ResourceRepository;

class DashboardController extends Controller
{
	protected $user;
    protected $order;
    protected $product;
    protected $request;

    function __construct(User $user,Order $order,Product $product,Request $request)
    {
        $this->user = new ResourceRepository($user);
        $this->product = new ResourceRepository($product);
        $this->order = new ResourceRepository($order);
    	$this->request = $request; 
    }

    public function index()
    {    
        $type = Auth::user()->accountType;
        if($type == 'admin'){
            $data = [
                    'branches' => $this->user->getCount(['accountType' => 'branch']),
                    'drivers' => $this->user->getCount(['accountType' => 'driver']),
                    'orders' => $this->order->getCount(['status' => '1']),
                    'product' => $this->product->getCount(['status' => '1']),
            ];
        } elseif($type == 'branch'){
            $data = [ 
                    'drivers' => $this->user->getCount(['accountType' => 'driver','branch_id' => Auth::user()->id]),
                    'customers' => $this->user->getCount(['accountType' => 'customer','branch_id' => Auth::user()->id]),
                    'orders' => $this->order->getCount(['status' => '1','branch_id' => Auth::user()->id]), 
                    'for collection' => $this->order->getCount(['status' => '1','orderStatus' => 'collection','branch_id' => Auth::user()->id]),
            ];
        } else {
            $data = [  
                //'pickup' => $this->order->getCount(['status' => '1','orderStatus' => 'ready','branch_id' => Auth::user()->branch_id]), 
                    'delivering' => $this->order->getCount(['status' => '1','orderStatus' => 'pickup','driver_id' => Auth::user()->id,'branch_id' => Auth::user()->branch_id]), 
                    'collection' => $this->order->getCount(['status' => '1','orderStatus' => 'collection','driver_id' => Auth::user()->id,'branch_id' => Auth::user()->branch_id]), 
                    'redelivery' => $this->order->getCount(['status' => '1','orderStatus' => 'redeliver','driver_id' => Auth::user()->id,'branch_id' => Auth::user()->branch_id]),
            ];
        }

    	return view('pages.dashboard.index')
    		->with([
                'title' => 'Dashboard',
                'active' => 'dashboard',
                'sub' => 'Summary',
                'data' => $data
            ]);
    }
 
}




