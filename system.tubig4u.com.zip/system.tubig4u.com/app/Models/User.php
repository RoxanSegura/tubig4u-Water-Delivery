<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;  
use Illuminate\Foundation\Auth\User as Authenticatable; 
use Auth;

class User extends Authenticatable
{
  	use Notifiable;
  	
	protected $table = 'users';

	protected $fillable = [
		'name','username','password','contact','address','plateNumber','accountType','branch_id','status','online'
	];
}
