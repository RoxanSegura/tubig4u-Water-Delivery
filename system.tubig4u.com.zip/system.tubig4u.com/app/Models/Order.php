<?php

namespace App\Models;
 
use Illuminate\Database\Eloquent\Model;   

class Order extends Model
{ 
	protected $table = 'orders';

	protected $fillable = [
		'refNo','branch_id','customer_id','driver_id','orders','orderStatus','status'
	];
}
