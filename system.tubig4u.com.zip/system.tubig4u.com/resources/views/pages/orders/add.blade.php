@extends('templates.layout.main')
@section('content')
    <div class="row">
        <div class="col">
            <h3>Add Information</h3>

            @if((session('success')))
                <p class="success">{{ session('success') }}</p>
            @elseif((session('error')))
                <p class="error">{{ session('error') }}</p>
            @endif

            <form method="post" action="{{ URL::route('app.orders.add.save') }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="exampleInputEmail1">Choose Customer</label>
                    <select type="text" class="chosen form-control" id="exampleInputEmail1" required name="customer">
                        @if($customers)
                            @foreach($customers as $v)
                                <option value="{{ $v->id }}">
                                    {{ $v->address }} - 
                                    @if(is_null($v->name))
                                        no name
                                    @else
                                        {{ $v->name }}
                                    @endif</option>
                            @endforeach
                        @endif
                    </select>
                    <p>Customer not registered ? <a href="{{ URL::route('app.customers.add') }}">Click me to create new customer </a></p>
                </div>
                <!--<div class="form-group">
                    <label for="exampleInputEmail1">Choose Deliery Boy</label>
                    <select type="text" class="chosen form-control" id="exampleInputEmail1" required name="delivery">
                        @if($drivers)
                            @foreach($drivers as $v)
                                <option value="{{ $v->id }}">{{ $v->name }}</option>
                            @endforeach
                        @endif
                    </select>
                    <p>Driver not registered ? <a href="{{ URL::route('app.drivers.add') }}">Click me to create new Driver </a></p>
                     </div>-->
                <input type="hidden" name="delivery" value="0" />
                <br>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th></th> 
                                <th>Product</th>
                                <th>Price</th> 
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @if($products)
                                @foreach($products as $k => $v)
                                    <tr>  
                                        <td class="min-width">
                                            <div class="avatar" style="background-image: url({{ URL::asset('public/img/product/'.$v->img) }});"></div> 
                                        </td>
                                        <td class="new-lines">{{ $v->name }}</td>
                                        <td class="new-lines"><b>P {{ number_format($v->price,2,'.',',') }}</b></td>
                                        <td class="">
                                            <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Qty" required name="{{ $v->id }}" value="0">
                                        </td>
                                    </tr> 
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="3">
                                        <center>
                                            No Customers Yet
                                        </center>
                                    </td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>

                <div class="form-check">
                    <button class="button-default button active" aria-current="true">Save</button>
                </div>
            </form>
        </div>
    </div>

    <style type="text/css">
        .error{
            color: red;
        }
        .success{
            color:green;
        }
    </style>
@endsection
@section('extraJs')
    <script type="text/javascript">
        $(".chosen").chosen();
    </script>
@endsection
