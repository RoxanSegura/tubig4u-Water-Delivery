@extends('templates.layout.main')
@section('content')     
    <ul class="nav nav-tabs">
        <!--<li class="active">
            <a data-toggle="tab" href="#home">
                For Pick-up
                @if(count($ready) > 0)
                    <kbd class="notif">{{ count($ready) }}</kbd>
                @endif
            </a>
        </li>-->
        <li class="active">
            <a data-toggle="tab" href="#menu1">
                On Delivery
                @if(count($ondelivery) > 0)
                    <kbd class="notif">{{ count($ondelivery) }}</kbd>
                @endif
            </a>
        </li>
        <li>
            <a data-toggle="tab" href="#menu2">
                For Re-delivery
                @if(count($redeliver) > 0)
                    <kbd class="notif">{{ count($redeliver) }}</kbd>
                @endif
            </a>
        </li> 
        <li>
            <a data-toggle="tab" href="#menu3">
                For Collection
                @if(count($collection) > 0)
                    <kbd class="notif">{{ count($collection) }}</kbd>
                @endif
            </a>
        </li> 
    </ul>

    <div class="tab-content">
        <div id="home" class="tab-pane fade in"> 
            <br>
            <div class="rowx">
                @if($ready)
                    @foreach($ready as $v)
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}"><small>#{{ $v->refNo }}</small></a> 
                                        <span style="float: right;">{{ $v->updated_at->diffForHumans() }}</span>  
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>
                                            @if (!is_null($v->driver_id))
                                                <b>Delivery Boy :</b><br>
                                                {{ App\Models\User::find($v->driver_id)->name }}
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                </div> 
                            </div>
                        </div> 
                    @endforeach
                @endif
            </div> 
        </div> 
        <div id="menu1" class="tab-pane fade in active"> 
            <br>
            <div class="rowx">
                @if($ondelivery)
                    @foreach($ondelivery as $v)
                        <div class="col-md-4x infobox queue">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}"><small>#{{ $v->refNo }}</small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?> 
                                        <a href="{{ URL::route('app.drivers.orders.updatestatus',[$v->id,'redeliver']) }}" class="decline-btn">
                                            RE-DELIVERY
                                        </a> 
                                        <a href="{{ URL::route('app.drivers.orders.updatestatus',[$v->id,'collection']) }}" class="decline-btn">
                                            FOR COLLECTION
                                        </a> 
                                        <!--<a href="{{ URL::route('app.drivers.orders.updatestatus',[$v->id,'delivered']) }}" class="accept-btn">
                                            DELIVERED
                                        </a>--> 
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>
                                            @if (!is_null($v->driver_id))
                                                <b>Delivery Boy :</b><br>
                                                {{ App\Models\User::find($v->driver_id)->name }}
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                </div> 
                            </div>
                        </div> 
                    @endforeach
                @endif
            </div> 
        </div> 
        <div id="menu2" class="tab-pane fade in"> 
            <br>
            <div class="rowx">
                @if($redeliver)
                    @foreach($redeliver as $v)
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}"><small>#{{ $v->refNo }}</small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?> 
                                        <span style="float: right;">{{ $v->updated_at->diffForHumans() }}</span> 
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>
                                            @if (!is_null($v->driver_id))
                                                <b>Delivery Boy :</b><br>
                                                {{ App\Models\User::find($v->driver_id)->name }}
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                </div> 
                            </div>
                        </div> 
                    @endforeach
                @endif
            </div> 
        </div>  
        <div id="menu3" class="tab-pane fade in"> 
            <br>
            <div class="rowx">
                @if($collection)
                    @foreach($collection as $v)
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}"><small>#{{ $v->refNo }}</small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?> 
                                        <a href="{{ URL::route('app.drivers.orders.updatestatus',[$v->id,'delivered']) }}" class="accept-btn">
                                            COLLECTED
                                        </a> 
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>
                                            @if (!is_null($v->driver_id))
                                                <b>Delivery Boy :</b><br>
                                                {{ App\Models\User::find($v->driver_id)->name }}
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                </div> 
                            </div>
                        </div> 
                    @endforeach
                @endif
            </div> 
        </div> 
    </div>

    <style type="text/css">
        kbd.notif{
            background-color: red;
            color: white;
            border-radius: 1500px; 
        }
        .accept-btn{
            background-color: green;
            color:white;
            font-weight: bolder;
            text-align: center;
            padding: 7px 10px;
            float: right; 
        }
        .decline-btn{
            background-color: red;
            color:white;
            margin-left: 1%;
            font-weight: bolder;
            text-align: center;
            padding: 7px 10px;
            float: right; 
        }
        .pending{
            border-left:5px solid red;
        }
        .queue{
            border-left:5px solid orange;
        }
        .queue-driver{
            border-left:5px solid blue;
        }
        .delivered{
            border-left:5px solid green;
        }
        .notdelivered{
            border-left:5px solid violet;
        }
        .forcollection{
            border-left:5px solid yellow;
        }
        .infobox{
            width: 99% !important;
            float: left;
            margin-right: 1%;
            padding: 10;
            height: 12em;
        }
        .lists{
            text-align: left important;
        }
        .ordering a{
            color: royalblue;
        }
    </style>
@endsection 

@section('extraJs')
    <script type="text/javascript">
     $('.nav-tabs li a').click(function() {
         let url = window.location.href.replace(/\#(.*)$/, '');
         window.location.href = url + $(this).attr('href');
         let u = '?prev_url=' + window.location.href + '#' + $(this).attr('href');
         
         $('.accept-btn').each(function() {
             $(this).attr('href', $(this).attr('href').replace(/\?(.*)/, '') + u);
         });
         
         $('.decline-btn').each(function() {
             $(this).attr('href', $(this).attr('href').replace(/\?(.*)/, '') + u);
         });
         
//         alert($(this).attr('href'));
     });

     $(document).ready(function() {
         let u = window.location.href.split('#');
         
         if (typeof u[1] == 'undefined') {
             return;
         }
         
         let id = u[1];

         let url = '?prev_url=' + window.location.href + '#' + id;
         $('.accept-btn').each(function() {
             $(this).attr('href', $(this).attr('href') + url);
         });
         
         $('.decline-btn').each(function() {
             $(this).attr('href', $(this).attr('href') + url);
         });
         
         $('.tab-content > div.tab-pane').removeClass('active');
         $('.tab-content > div.tab-pane#' + id).addClass('active');
         $('.nav-tabs a').parent().removeClass('active');
         $('.nav-tabs a[href="#' + id + '"]').parent().addClass('active');
     });
    </script>
@endsection
