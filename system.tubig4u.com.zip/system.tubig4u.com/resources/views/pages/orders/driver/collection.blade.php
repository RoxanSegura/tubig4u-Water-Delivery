@extends('templates.layout.main')
@section('content')  
    <div class="stacks" class="ordering"> 
        <div class="secondary stack-wrapper">
            <div class="stack">
                <h2>For Collection <small>(Delivered but no payment)</small></h2>
                <div class="stack-inner"> 
                	<h3>{{ count($collection) }} Total</h3>
                	<div class="projects">
                		@if($collection)
                			@foreach($collection as $v)
		                		<div class="infobox forcollection">
								    <div class="infobox-inner"> 
								        <div class="infobox-meta"> 
							        		<small>
							        			<a href="{{ URL::route('app.orders.summary',$v->id) }}"><small>#{{ $v->refNo }}</small></a>
                                                
                                                <a href="{{ URL::route('app.orders.summary.update',$v->id) }}" class="accept-btn">
                                                    UPDATE
                                                </a> 
							        		</small>
							        		<hr>
                                            <h3>
                                                {{ App\Models\User::find($v->customer_id)->name }} <br>
                                                <small>
                                                    {{ App\Models\User::find($v->customer_id)->address }}
                                                </small>
                                                <br>                                                
                                                <b>DRIVER : {{ App\Models\User::find($v->driver_id)->name }}</b>
                                            </h3> 
							        		@foreach(json_decode($v->orders) as $x)
								        		<span>
								        			<small>
								        				{{ $x->qty }} x <b>{{ $x->name }}</b>
								        			</small>
								        		</span> 
							        		@endforeach
								        </div> 
								    </div>
								</div>
							@endforeach
						@endif
                	</div> 
                </div>
            </div>
        </div>  
    </div> 

    <style type="text/css">
    	.accept-btn{
    		background-color: green;
    		color:white;
    		font-weight: bolder;
    		text-align: center;
    		padding: 1%;
    		float: right; 
    		font-size: 0.8em;
    	}
    	.decline-btn{
    		background-color: red;
    		color:white;
    		margin-left: 1%;
    		font-weight: bolder;
    		text-align: center;
    		padding: 1%;
    		float: right; 
    		font-size: 0.8em;
    	}
    	.projects .pending{
    		border-left:5px solid red;
    	}
    	.projects .queue{
    		border-left:5px solid orange;
    	}
    	.projects .queue-driver{
    		border-left:5px solid blue;
    	}
    	.projects .delivered{
    		border-left:5px solid green;
    	}
    	.projects .notdelivered{
    		border-left:5px solid violet;
    	}
    	.projects .forcollection{
    		border-left:5px solid yellow;
    	}
    	.infobox{
    		width: 100% !important;
    		padding: 10;
    	}
    	.lists{
    		text-align: left important;
    	}
    	.ordering a{
    		color: royalblue;
    	}
    </style>
@endsection 