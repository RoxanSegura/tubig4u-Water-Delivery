@extends('templates.layout.main')
@section('content')     
    <ul class="nav nav-tabs">
        <li class="active">
            <a data-toggle="tab" href="#home">
                On Delivery
                @if(count($pending) > 0)
                    <kbd class="notif">{{ count($pending) }}</kbd>
                @endif
            </a>
        </li>
        <li>
            <a data-toggle="tab" href="#menu1">
                For Re-delivery
                @if(count($redeliver) > 0)
                    <kbd class="notif">{{ count($redeliver) }}</kbd>
                @endif
            </a>
        </li> 
        <li>
            <a data-toggle="tab" href="#menu2">
                For Collection
                @if(count($collection) > 0)
                    <kbd class="notif">{{ count($collection) }}</kbd>
                @endif
            </a>
        </li> 
    </ul>

    <div class="tab-content">
        <div id="home" class="tab-pane fade in active"> 
            <br>
            <div class="rowx">
                @if($pending)
                    @foreach($pending as $v)
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}"><small>#{{ $v->refNo }}</small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?>
                                        @if(round($interval->format('%H.%i')) >= 2) 
                                            <a href="{{ URL::route('app.orders.redeliver',$v->id) }}" class="decline-btn">
                                                RE-DELIVERY
                                            </a> 
                                        @else
                                            <span style="float: right;">{{ $v->updated_at->diffForHumans() }}</span>
                                        @endif
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>
                                            @if (!is_null($v->driver_id))
                                                <b>Delivery Boy :</b><br>
                                                {{ App\Models\User::find($v->driver_id)->name }}
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                </div> 
                            </div>
                        </div> 
                    @endforeach
                @endif
            </div> 
        </div>
        <div id="menu1" class="tab-pane fade in">
            @if(session('error'))
                <br />
                <div>
                    <small class="text-danger"><kbd class="notif">!</kbd> {{session('error')}}</small>
                </div>
            @endif
            <br> 
            <div class="rowx"> 
                @if($redeliver)
                    @foreach($redeliver as $v)
                        @if(is_null($v->driver_id))
                            <div class="col-md-4x infobox queue">
                        @else 
                            <div class="col-md-4x infobox queue-driver">
                        @endif
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}">#{{ $v->refNo }}</a>   
                                        <!--<a href="{{ URL::route('app.orders.pickup',$v->id) }}" class="accept-btn">
                                            PICK-UP
                                        </a>-->
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>

                                            @if (!is_null($v->driver_id))
                                                <b>LAST DELIVERY BOY : {{ App\Models\User::find($v->driver_id)->name }}</b>
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                    <hr />
                                    <form method="get" action="{{ URL::route('app.orders.move', $v->id) }}">
                                        <input type="hidden" name="prev_url" id="prev-url" />
                                            <div>
                                                <label>Choose Delivery Boy</label>
                                                @if (!$drivers->isEmpty())
                                                    <select type="text" class="chosen form-control" required name="driver">
                                                        @foreach ($drivers as $driver)
                                                            <option {{(time() - 60 > strtotime($driver->online)) ? 'disabled="disabled"' : null }} value="{{$driver->id}}">{{$driver->name}}</option>
                                                        @endforeach
                                                    </select>
                                                @else
                                                    <span class="text-danger">No delivery boy available</span>
                                                @endif
                                            </div>
                                            <br />
                                            <button type="submit" class="accept-btn">MOVE</button>
                                    </form>
                                </div> 
                            </div>
                        </div>
                    @endforeach
                @endif
            </div> 
        </div>  
        <div id="menu2" class="tab-pane fade in">
            <br> 
            <div class="rowx"> 
                @if($collection)
                    @foreach($collection as $v)
                        @if(is_null($v->driver_id))
                            <div class="col-md-4x infobox queue">
                        @else 
                            <div class="col-md-4x infobox queue-driver">
                        @endif
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="{{ URL::route('app.orders.summary',$v->id) }}">#{{ $v->refNo }}</a>    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            {{ App\Models\User::find($v->customer_id)->address }}
                                            <br>

                                            @if (!is_null($v->driver_id))
                                                <b>Delivery Boy : {{ App\Models\User::find($v->driver_id)->name }}</b>
                                            @endif
                                        </small>
                                    </h3> 
                                    @foreach(json_decode($v->orders) as $x)
                                        <span>
                                            <small>
                                                {{ $x->qty }} x <b>{{ $x->name }}</b>
                                            </small>
                                        </span> 
                                    @endforeach
                                </div> 
                            </div>
                        </div>
                    @endforeach
                @endif
            </div> 
        </div> 
    </div>

    <style type="text/css">
        kbd.notif{
            background-color: red;
            color: white;
            border-radius: 1500px; 
        }
        .accept-btn{
            background-color: green;
            border: none;
            color:white;
            font-weight: bolder;
            text-align: center;
            padding: 7px 10px;
            float: right; 
        }
        .decline-btn{
            background-color: red;
            border: none;
            color:white;
            margin-left: 1%;
            font-weight: bolder;
            text-align: center;
            padding: 7px 10px;
            float: right; 
        }
        .pending{
            border-left:5px solid red;
        }
        .queue{
            border-left:5px solid orange;
        }
        .queue-driver{
            border-left:5px solid blue;
        }
        .delivered{
            border-left:5px solid green;
        }
        .notdelivered{
            border-left:5px solid violet;
        }
        .forcollection{
            border-left:5px solid yellow;
        }
        .infobox{
            width: 99% !important;
            float: left;
            margin-right: 1%;
            padding: 10;
            height: 21em;
        }
        .lists{
            text-align: left important;
        }
        .ordering a{
            color: royalblue;
        }

        .chosen-container { width: 100% !important; }
    </style>
@endsection 

@section('extraJs')
    <script type="text/javascript">
     $(".chosen").chosen();
     
     $('.nav-tabs li a').click(function() {
         let url = window.location.href.replace(/\#(.*)$/, '');
         $('#prev-url').val(url + $(this).attr('href'));
         window.location.href = url + $(this).attr('href');
//         alert($(this).attr('href'));
     });
     
     $(document).ready(function() {
         let u = window.location.href.split('#');
         
         if (typeof u[1] == 'undefined') {
             return;
         }
         
         let id = u[1];
         
         $('#prev-url').val(window.location.href);
         $('.tab-content > div.tab-pane').removeClass('active');
         $('.tab-content > div.tab-pane#' + id).addClass('active');
         $('.nav-tabs a').parent().removeClass('active');
         $('.nav-tabs a[href="#' + id + '"]').parent().addClass('active');
     });
    </script>
@endsection
