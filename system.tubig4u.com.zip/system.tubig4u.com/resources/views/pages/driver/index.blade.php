@extends('templates.layout.main')
@section('content')
    <div class="filter form-inline"> 
        <div class="form-group form-group-description">[~] - Add new <br>Displaying {{ count($data) }} items matching your criteria.</div> 
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Name</th> 
                    <th>Address</th>
                    <th>Plate Number</th>
                    <th>Online</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @if($data)
                    @foreach($data as $k => $v)
                        <tr id="{{ $v->id }}">
                            <td class="min-width"> 
                                <div class="title-wrapper">
                                    <div class="title">{{ ucfirst($v->name) }}</div>
                                    <div class="subtitle">{{ $v->contact}}</div>
                                </div>
                            </td> 
                            <td class="new-lines">{{ $v->address }}</td>
                            <td class="new-lines">{{ $v->plateNumber }}</td>  
                            <td class="new-lines online_status">Oflline</td>  
                            <td class="actions min-width">
                                <div class="button-dropdown">
                                    <i class="md-icon">more_horiz</i>
                                    <ul>
                                        <li><a href="{{ URL::route('app.drivers.update',$v->id) }}" class="action-btn">Update</a></li> 
                                        <li><a href="{{ URL::route('app.drivers.delete',$v->id) }}" class="action-btn">Delete</a></li> 
                                    </ul>
                                </div>
                            </td>
                        </tr> 
                    @endforeach
                @else
                    <tr>
                        <td colspan="3">
                            <center>
                                No Customers Yet
                            </center>
                        </td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

    <script type="text/javascript">
        $(document).ready(()=>{
            
            online = [];
            setInterval(() => {
                $.get('{{ URL::route("app.online.branch") }}?branch_id={{ Auth::id() }}',function(res){
                    onlineNow = [];
                    for(i=0; i < res.length; i++){
                        $('#'+res[i].id+' .online_status').html('Online').addClass('onlinestat'); 

                        if(!online.includes(res[i].id)){
                            online.push(res[i].id);
                            console.log('New online was added !');
                        }

                        onlineNow.push(res[i].id);
                    }  

                    for(i=0; i < online.length; i++){ 
                        if(!onlineNow.includes(online[i])){
                            console.log('Someone is offline !');
                            $('body .online_status').html('Offline').removeClass('onlinestat');
                            online.splice(i,1);
                        }
                    }   
                });

            },1000);

        });
    </script>
    <style type="text/css"> 
        .onlinestat{
            color:yellowgreen !important;
        }
        .online_status{
            color:red;
        }
        .action-btn{
            text-align: center;
            cursor: pointer;
        }
    </style>
@endsection
