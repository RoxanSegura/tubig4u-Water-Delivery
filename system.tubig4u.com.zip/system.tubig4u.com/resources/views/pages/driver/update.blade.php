@extends('templates.layout.main')
@section('content')
    <div class="row">
        <div class="col">
            <h3>Update Information</h3>

            @if((session('success')))
                <p class="success">{{ session('success') }}</p>
            @elseif((session('error')))
                <p class="error">{{ session('error') }}</p>
            @endif

            <form method="post" action="{{ URL::route('app.drivers.update.save',$data->id) }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="exampleInputEmail1">Full Name</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter name" required name="name" value="{{ $data->name }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Contact</label>
                    <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Contact Number" required name="contact" value="{{ $data->contact }}">
                </div>
                <div class="form-group">
                    <label for="exampleTextarea">Address</label>
                    <textarea class="form-control" id="exampleTextarea" rows="15" required name="address">{{ $data->address }}</textarea>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Plate Number</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Plate Number" required name="plateNumber" value="{{ $data->plateNumber }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Username</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Usernmae" required name="username" value="{{ $data->username }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
                </div>  
                <div class="form-check">
                    <button class="button-default button active" aria-current="true">Save</button>
                </div>
            </form>
        </div>
    </div>

    <style type="text/css">
        .error{
            color: red;
        }
        .success{
            color:green;
        }
    </style>
@endsection