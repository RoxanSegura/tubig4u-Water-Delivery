@extends('templates.layout.main')
@section('content')
    <div class="filter form-inline"> 
        <div class="form-group form-group-description">[~] - Add new <br>Displaying {{ count($data) }} items matching your criteria.</div> 
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th></th> 
                    <th>Product</th>
                    <th>Price</th> 
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @if($data)
                    @foreach($data as $k => $v)
                        <tr>  
                            <td class="min-width">
                                <div class="avatar" style="background-image: url({{ URL::asset('public/img/product/'.$v->img) }});"></div> 
                            </td>
                            <td class="new-lines">{{ $v->name }}</td>
                            <td class="new-lines"><b>P {{ number_format($v->price,2,'.',',') }}</b></td>
                            <td class="actions min-width">
                                <div class="button-dropdown">
                                    <i class="md-icon">more_horiz</i>
                                    <ul>
                                        <li><a href="{{ URL::route('app.product.update',$v->id) }}" class="action-btn">Update</a></li> 
                                        <li><a href="{{ URL::route('app.product.delete',$v->id) }}" class="action-btn">Delete</a></li> 
                                    </ul>
                                </div>
                            </td>
                        </tr> 
                    @endforeach
                @else
                    <tr>
                        <td colspan="3">
                            <center>
                                No Customers Yet
                            </center>
                        </td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

    <style type="text/css">
        .action-btn{
            text-align: center;
            cursor: pointer;
        }
    </style>
@endsection