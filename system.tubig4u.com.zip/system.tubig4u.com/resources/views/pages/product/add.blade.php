@extends('templates.layout.main')
@section('content')
    <div class="row">
        <div class="col">
            <h3>Add Information</h3>

            @if((session('success')))
                <p class="success">{{ session('success') }}</p>
            @elseif((session('error')))
                <p class="error">{{ session('error') }}</p>
            @endif

            <form method="post" action="{{ URL::route('app.product.add.save') }}" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="exampleInputEmail1">Product Name</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter name" required name="name">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Price</label>
                    <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Contact Number" required name="price">
                </div>
                <div class="form-group">
                    <label for="exampleTextarea">Image</label>
                    <input type="file" class="form-coxntrol" id="exxampleInputPassword1" required name="img">
                </div>   
                <div class="form-check">
                    <button class="button-default button active" aria-current="true">Save</button>
                </div>
            </form>
        </div>
    </div>

    <style type="text/css">
        .error{
            color: red;
        }
        .success{
            color:green;
        }
    </style>
@endsection