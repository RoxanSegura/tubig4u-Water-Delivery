@extends('templates.layout.blank')
@section('content')
    <div class="page-empty-content">
        <center>
            <img src="{{ URL::asset('public/img/logo.png') }}" class="logo">
        </center>
        <h1>{{ $title }}</h1>
        <form method="post" action="{{ URL::route('app.login.verify') }}">
            {{ csrf_field() }}

            @if($errors->any())
                @foreach($errors->all() as $err)
                    <p class="danger">{{ $err }}</p>
                @endforeach 
            @endif

            @if(session('error') !== null)
                <p class="danger">{{ session('error') }}</p>
            @endif
            
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="form-group form-group-button"> 
                <button type="submit" class="button button-primary button-right">Login</button>
            </div>
        </form> 
    </div>

    <style type="text/css">
        .danger{
            color: red;
        }
        .logo{
            width: 30%;
            margin-bottom: 5%;

        }
    </style>
@endsection