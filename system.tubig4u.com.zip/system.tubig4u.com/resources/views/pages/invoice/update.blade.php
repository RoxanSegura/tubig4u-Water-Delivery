@extends('templates.layout.main')
@section('content')
    <div class="invoice-wrapper">
        <div class="invoice">
            <div class="invoice-header">
                <div class="invoice-logo">
                	<h3>
                		REFID : #{{ $data->refNo }}
                        <br>
                        <small>{{ UCFIRST($data->orderStatus) }}</small>
                	</h3>
                </div>
                <div class="invoice-description"><strong>{{ date('M d, Y',strtotime($data->created_at)) }}</strong><span>{{ date('h:i A',strtotime($data->created_at)) }}</span></div>
            </div>
            <div class="invoice-info">
                <div class="invoice-info-client">
                    <h4>Customer Details</h4>
                    <p>
                        {{ App\Models\User::find($data->customer_id)->name }} 
                        <br>
                        <br>
                        {{ App\Models\User::find($data->customer_id)->contact }}
                    </p>
                    <address>
                        {{ App\Models\User::find($data->customer_id)->address }}
                    </address>
                </div>
                <div class="invoice-info-payment">
                    <h4>Driver Details</h4>
                    @if(App\Models\User::find($data->driver_id))
                    <p>
                        {{ App\Models\User::find($data->driver_id)->name }} 
                        <br>
                        <br>
                        {{ App\Models\User::find($data->driver_id)->contact }}
                    </p>
                    <address>
                        {{ App\Models\User::find($data->driver_id)->address }}
                    </address>
                    @else
                        <p><small>No driver assigned</small></p>
                    @endif
                </div>
            </div>
            <div class="invoice-table">
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Item</th>  
                            <th>Quantity</th>
                            <th>Unit Cost</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $total = 0;
                        ?>
                        @foreach(json_decode($data->orders) as $x)
                            <?php 
                                $total = $total + ($x->price*$x->qty);
                            ?>
                            <tr>
                                <td></td>
                                <td>{{ $x->name }}</td>
                                <td>{{ $x->qty }}</td>
                                <td>P {{ number_format($x->price,2,'.',',') }}</td> 
                                <td>P {{ number_format(($x->price*$x->qty),2,'.',',') }}</td>
                            </tr> 
                        @endforeach
                    </tbody>
                </table>


                <br><br><br>
                <form method="post" action="{{ URL::route('app.orders.summary.update.save',$data->id) }}" style="padding: 6%;">
                    {{ csrf_field() }} 
                    <div class="form-group">
                        <label for="exampleInputPassword1">Delivery Status</label>
                        <select class="form-control" id="exampleInputPassword1" required name="status">
                            <option value="redeliver">FOR REDELIVERY</option>
                            <option value="collection">FOR COLLECTION</option>
                            <option value="delivered">DELIVERED</option>
                        </select>
                    </div>  
                    <div class="form-check">
                        <button class="button-default button active" aria-current="true">UPDATE ORDER STATUS</button>
                    </div>
                </form>
            </div>
            <div class="invoice-summary"> 
                <div><span>Total Amount</span><strong>P {{ number_format($total,2,'.',',') }}</strong></div>
            </div>
        </div>
    </div> 
@endsection