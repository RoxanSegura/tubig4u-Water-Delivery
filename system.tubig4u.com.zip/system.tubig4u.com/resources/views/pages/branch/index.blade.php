@extends('templates.layout.main')
@section('content')
    <div class="filter form-inline"> 
        <div class="form-group form-group-description">[~] - Add new <br>Displaying {{ count($data) }} items matching your criteria.</div> 
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Branch</th> 
                    <th>Address</th>
                    <th>Contact</th> 
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @if($data)
                    @foreach($data as $k => $v)
                        <tr>  
                            <td class="new-lines"><b>{{ ucfirst($v->name) }}</b></td>
                            <td class="new-lines">{{ $v->address }}</td>
                            <td class="new-lines">{{ $v->contact }}</td>
                            <td class="actions min-width">
                                <div class="button-dropdown">
                                    <i class="md-icon">more_horiz</i>
                                    <ul>
                                        <li><a href="{{ URL::route('app.branch.update',$v->id) }}" class="action-btn">Update</a></li> 
                                        <li><a href="{{ URL::route('app.branch.delete',$v->id) }}" class="action-btn">Delete</a></li> 
                                    </ul>
                                </div>
                            </td>
                        </tr> 
                    @endforeach
                @else
                    <tr>
                        <td colspan="3">
                            <center>
                                No Customers Yet
                            </center>
                        </td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

    <style type="text/css">
        .action-btn{
            text-align: center;
            cursor: pointer;
        }
    </style>
@endsection