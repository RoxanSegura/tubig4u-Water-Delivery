@extends('templates.layout.main')
@section('content')
    <div class="border-bottom side-margins no-vertical-distance box">
        <div class="stats-wrapper">
            @foreach($data as $k => $v)
                <div class="stat-item">
                    <div class="stat-item-value">{{ $v }}</div>
                    <div class="stat-item-title">{{ ucfirst($k) }}</div> 
                </div>    
            @endforeach
        </div>
    </div>
@endsection