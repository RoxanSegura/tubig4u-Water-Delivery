<div class="toolbar">
    <div class="toolbar-inner">
        <div class="logo" style="padding-top: 3em;">
            <img src="{{ URL::asset('public/img/logo.png') }}">
        </div>
        <ul class="top">
            @if(App\Services\Acl::create('addButton'))
                <?php  
                    $noAddfeature = ['dashboard','report','orders.processing','orders.collection']
                ?>
                @if(!in_array($active,$noAddfeature)) 
                    <li>
                        <a href="{{ URL::route('app.'.$active.'.add') }}"
                           title="{{ strtolower($active)=='orders' ? '[F10] ' : ''}}Create {{ucwords($active)}}"
                           id="{{ strtolower($active)=='orders' ? 'add-order-btn' : ''}}">
                            <i class="md-icon">add</i>
                        </a>
                    </li>   
                @endif
            @endif
            <li><a onclick="$('.sidebar').toggle()" class="hideNav" title="Toggle Sidebar"><i class="md-icon">fullscreen</i></a></li>
            <li><a href="{{ URL::route('app.logout') }}" title="logout"><i class="md-icon">power_settings_new</i></a></li>
        </ul> 
        <ul class="bottom"></ul> 
    </div>
</div>
