<div class="page-title">
    <ul class="breadcrumbs">
        <li><a class="active" aria-current="true">{{ $title }}</a></li>
        <li><span>{{ $sub }}</span></li>
    </ul>
    <h1>{{ $title.' '.$sub }}</h1> 
</div>