<div class="footer">
    <div class="footer-left">© {{ date('Y') }} Tubig App. All rights reserved.</div>
    <!-- <div class="footer-right">
        <ul> 
            <li><a>Contact</a></li>
        </ul>
    </div> -->
</div>  