<ul class="pagination">
    <li class="previous disabled"><a tabindex="0">Previous</a></li>
    <li class="selected"><a tabindex="0" aria-label="Page 1 is your current page" aria-current="page">1</a></li>
    <li><a tabindex="0" aria-label="Page 2">2</a></li>
    <li><a tabindex="0" aria-label="Page 3">3</a></li>
    <li class="break">...</li>
    <li><a tabindex="0" aria-label="Page 8">8</a></li>
    <li><a tabindex="0" aria-label="Page 9">9</a></li>
    <li><a tabindex="0" aria-label="Page 10">10</a></li>
    <li class="next"><a tabindex="0">Next</a></li>
</ul> 