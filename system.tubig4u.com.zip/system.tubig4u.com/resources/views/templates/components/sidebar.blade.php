<div class="sidebar">
    <h1 class="sidebar-title-wrapper">
        <div class="sidebar-title-inner">
            <div class="sidebar-subtitle">
                <small>{{ strtoupper(Auth::user()->accountType) }}</small>
            </div>
            <div class="sidebar-title">{{ Auth::user()->name }}</div> 
        </div> 
    </h1>
    <div class="navigation">
        <ul>  
            @foreach(App\Services\Acl::navigation() as $k => $v)
                <li>
                    <a aria-current="false" href="{{ URL::route($v['url']) }}" @if($active ===  $v['active']) class="active" @endif>
                        <i class="md-icon">{{ $v['icon'] }}</i> 
                        <span>{{ ucfirst($v['title']) }}</span>
                        @if(isset($v['notif']) && $v['notif'] != 0)
                            <kbd>{{ $v['notif'] }}</kbd>
                        @endif
                    </a>
                </li>
            @endforeach 
        </ul> 
    </div>
</div>

<style type="text/css">
    kbd{
        background-color: red;
    }
    .badge{
        text-align: right;
        font-size: 0.7em;
        background-color: red;
        color:white;
        border-radius: 1500px;
        padding-right: 3%;
        padding-left: 3%;
        padding-top: 1%;
        padding-bottom: 1%;
    }
</style>