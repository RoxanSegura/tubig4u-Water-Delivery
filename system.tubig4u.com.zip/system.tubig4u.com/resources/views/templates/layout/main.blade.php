@extends('templates.layout.asset')
@section('body')
    <div id="root" class="page-wrapper">
        <div class="page-inner">
            
            @include('templates.components.aside')
            @include('templates.components.sidebar')

            <div class="main">
                @include('templates.components.breadcrumbs')

                <div class="content">
                    <div class="content-inner"> 
                        @yield('content')
                    </div>
                </div>

                @include('templates.components.footer')

            </div> 
        </div>
    </div> 

    @if(Auth::id())
        <!-- update online status -->
        <script type="text/javascript">
            $(document).ready(()=>{
                
                setInterval(() => {

                    $.get('{{ URL::route("app.online") }}?user_id={{ Auth::id() }}',function(res){
                        //console.log(res);
                    });

                },1000);

            });
        </script>
    @endif
@endsection