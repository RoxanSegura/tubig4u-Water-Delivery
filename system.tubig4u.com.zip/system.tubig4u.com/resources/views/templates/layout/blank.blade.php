@extends('templates.layout.asset')
@section('body')
    <div id="root" class="page-wrapper">
        <div class="page-empty">
            @yield('content')
        </div>
    </div>
@endsection