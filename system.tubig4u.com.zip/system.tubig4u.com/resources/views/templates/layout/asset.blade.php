<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name="theme-color" content="#000000"> 
    <link rel="stylesheet" href="{{ URL::asset('public/css/chart.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="{{ URL::asset('public/css/theme.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('public/css/chosen.css') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <title>{{ $title }} | TUBIG APP</title>
</head>

<body>
    @yield('body') 

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="{{ URL::asset('public/js/chosen.js') }}"></script>
    @if(Auth::user())
        @include('templates.shortcuts.'.Auth::user()->accountType)
    @endif
	@yield('extraJs')
</body> 
</html>