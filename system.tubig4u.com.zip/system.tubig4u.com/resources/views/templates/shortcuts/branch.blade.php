<script type="text/javascript">
    $(document).ready(function(){  
    	//$('.sidebar').toggle();
	    $(document).on( "keydown", function( event ) {
	    	url = [];
	    	url[112] = "{{ URL::route('app.dashboard') }}"; 
	    	url[113] = "{{ URL::route('app.customers') }}"; 
	    	url[114] = "{{ URL::route('app.drivers') }}"; 
	    	url[115] = "{{ URL::route('app.orders') }}";  
	    	url[116] = "{{ URL::route('app.orders.processing') }}";  
	    	url[117] = "{{ URL::route('app.orders.collection') }}"; 
	    	
	    	none = ['dashboard','report','orders.processing','orders.collection'];
    		url[192] = "{{ URL::route('app.'.$active) }}";
            url[121] = "{{ URL::route('app.orders.add')}}";

	    	console.log(event.which);
	    	if(event.which =='27'){
	    		$('.hideNav').click();
	    	} else if(url[event.which] != undefined){  
	    		if(event.which == 192){ 
	    			if(!none.includes('{{ $active }}')){  
	   					document.location.href = url[event.which]+'/add'; 
	    			}
	    		} else {
	   				document.location.href = url[event.which]; 
	   			}
	   		}
		}); 
	});
</script>
