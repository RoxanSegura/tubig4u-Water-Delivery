<div class="sidebar">
    <h1 class="sidebar-title-wrapper">
        <div class="sidebar-title-inner">
            <div class="sidebar-subtitle">
                <small><?php echo e(strtoupper(Auth::user()->accountType)); ?></small>
            </div>
            <div class="sidebar-title"><?php echo e(Auth::user()->name); ?></div> 
        </div> 
    </h1>
    <div class="navigation">
        <ul>  
            <?php $__currentLoopData = App\Services\Acl::navigation(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a aria-current="false" href="<?php echo e(URL::route($v['url'])); ?>" <?php if($active ===  $v['active']): ?> class="active" <?php endif; ?>>
                        <i class="md-icon"><?php echo e($v['icon']); ?></i> 
                        <span><?php echo e(ucfirst($v['title'])); ?></span>
                        <?php if(isset($v['notif']) && $v['notif'] != 0): ?>
                            <kbd><?php echo e($v['notif']); ?></kbd>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </ul> 
    </div>
</div>

<style type="text/css">
    kbd{
        background-color: red;
    }
    .badge{
        text-align: right;
        font-size: 0.7em;
        background-color: red;
        color:white;
        border-radius: 1500px;
        padding-right: 3%;
        padding-left: 3%;
        padding-top: 1%;
        padding-bottom: 1%;
    }
</style><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/components/sidebar.blade.php ENDPATH**/ ?>