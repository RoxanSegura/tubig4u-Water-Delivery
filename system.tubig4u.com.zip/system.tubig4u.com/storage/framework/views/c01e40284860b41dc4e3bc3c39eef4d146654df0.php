<script type="text/javascript">
    $(document).ready(function(){  
    	//$('.sidebar').toggle();
	    $(document).on( "keydown", function( event ) {
	    	url = [];
	    	url[112] = "<?php echo e(URL::route('app.dashboard')); ?>"; 
	    	url[113] = "<?php echo e(URL::route('app.branch')); ?>"; 
	    	url[114] = "<?php echo e(URL::route('app.product')); ?>"; 
	    	url[115] = "<?php echo e(URL::route('app.report')); ?>"; 
	    	
	    	none = ['dashboard','report'];
    		url[192] = "<?php echo e(URL::route('app.'.$active)); ?>"; 

	    	console.log(event.which);

	    	if(event.which =='27'){
	    		$('.hideNav').click();
	    	} else if(url[event.which] != undefined){  
	    		if(event.which == 192){ 
	    			if(!none.includes('<?php echo e($active); ?>')){  
	   					document.location.href = url[event.which]+'/add'; 
	    			}
	    		} else {
	   				document.location.href = url[event.which]; 
	   			}
	   		}
		}); 
	});
</script><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/shortcuts/admin.blade.php ENDPATH**/ ?>