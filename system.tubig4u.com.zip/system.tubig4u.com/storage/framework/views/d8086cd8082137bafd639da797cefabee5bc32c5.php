<?php $__env->startSection('content'); ?> 
  <div class="table-responsive">
    <table id="examplxe" class="display" style="width:100%">
      <thead>
          <?php if(!isset($_GET['today'])): ?>
            <tr>
              <th>REF ID</th> 
              <th>Orders</th>
              <th>Total</th>
              <th>Customer</th>
              <th>Driver</th>
              <th>Status</th> 
              <th>Date</th>
            </tr>
          <?php else: ?>
            <tr> 
                <td>Status</td>
                <td>Product</td>
                <td>Quantity</td>
                <td>Subtotal</td>
            </tr>
          <?php endif; ?>
      </thead>
      <tbody>
        <?php $totals = []; ?>
        <?php if($data['data']): ?>
          <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
                if(!array_key_exists($v->orderStatus,$totals)){
                    $totals[$v->orderStatus] = []; 
                }
                
                if(!array_key_exists('total',$totals[$v->orderStatus])){ 
                    $totals[$v->orderStatus]['total']['qty'] = 0; 
                    $totals[$v->orderStatus]['total']['sale'] = 0; 
                }
                
                foreach(json_decode($v->orders) as $x){
                    $name = str_replace(' ','_',str_replace('-','',strtolower($x->name)));
                    
                    if(!array_key_exists($name,$totals[$v->orderStatus])){
                        $totals[$v->orderStatus][$name]['qty'] = 0; 
                        $totals[$v->orderStatus][$name]['sale'] = 0; 
                    }
                    
                    $totals[$v->orderStatus][$name]['qty'] += $x->qty;
                    $totals[$v->orderStatus][$name]['sale'] += $x->qty * $x->price;
                    $totals[$v->orderStatus]['total']['qty'] += $x->qty;
                    $totals[$v->orderStatus]['total']['sale'] += $x->qty * $x->price;
                } 
            ?>
          <?php if(!isset($_GET['today'])): ?>
            <tr> 
              <td class="new-lines">#<?php echo e($v->refNo); ?></td>  
              <td class="min-width"><?php 
              $orders = [];
              $orders = json_decode($v->orders);
              $total = 0;
              ?><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><small><b><?php echo e($x->name); ?></b> x <?php echo e($x->qty); ?></small><?php $total = $total + ($x->price*$x->qty); ?><br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>  
              <td class="new-lines">P <?php echo e(number_format($total,2,'.',',')); ?></td>
              <?php if($v->customer_id): ?>
                <td class="new-lines"><?php echo e(App\Models\User::find($v->customer_id)->name); ?></td>
              <?php else: ?>
                <td class="new-lines">---</td>
              <?php endif; ?>

              <?php if($v->driver_id): ?>
                <td class="new-lines"><?php echo e(App\Models\User::find($v->driver_id)->name); ?></td>
              <?php else: ?>
                <td class="new-lines">---</td>
              <?php endif; ?>
              <td class="new-lines"><?php echo e(ucfirst($v->orderStatus)); ?></td>
              <td class="new-lines"><?php echo e($v->updated_at); ?></td>
            </tr> 
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
             
          <?php if(isset($_GET['today'])): ?>
                 <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                        <td><b><?php echo e(strtoupper($k)); ?></b></td>
                        <td></td> 
                        <td></td> 
                        <td></td> 
                    </tr>
                    
                    <?php $__currentLoopData = array_reverse($x); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kz => $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> 
                            <td></td> 
                            <td><?php echo e(str_replace('_',' ',$kz)); ?></td>
                            <td><?php echo e($z['qty']); ?></td>
                            <td>P <?php echo e($z['sale']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>
        <?php else: ?>
              <tr>
                <td colspan="3">
                  <center>
                    No data found
                  </center>
                </td>
              </tr>
        <?php endif; ?>
      </tbody>
    </table> 
  </div>

  <style type="text/css">
   .action-btn{
     text-align: center;
     cursor: pointer;
   }
   .print-btn{
     float: right;
     border:none;
     outline: none;
     background-color: blue;
     width: 10%;
     padding: 1%;
     color:white;
   }

   @media  print{
   .sidebar, .print-btn, .toolbar {
     display: none !important;
   }
   }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraJs'); ?>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">
  <script src='https://code.jquery.com/jquery-3.3.1.js'></script>
  <script src='https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js'></script>
  <script src='https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js'></script>
  <script src='https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js'></script>
  <script type="text/javascript">
   $(document).ready(function() {
     $('#example').DataTable( {
       dom: 'Bfrtip',
       buttons: [
         'copyHtml5',
         'excelHtml5',
         'csvHtml5',
         'pdfHtml5'
       ]
     });
   });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/report/results.blade.php ENDPATH**/ ?>