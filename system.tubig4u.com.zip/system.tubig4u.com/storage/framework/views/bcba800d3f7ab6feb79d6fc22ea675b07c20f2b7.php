<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name="theme-color" content="#000000"> 
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/css/chart.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/css/theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/css/chosen.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <title><?php echo e($title); ?> | TUBIG APP</title>
</head>

<body>
    <?php echo $__env->yieldContent('body'); ?> 

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="<?php echo e(URL::asset('public/js/chosen.js')); ?>"></script>
    <?php if(Auth::user()): ?>
        <?php echo $__env->make('templates.shortcuts.'.Auth::user()->accountType, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
	<?php echo $__env->yieldContent('extraJs'); ?>
</body> 
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/layout/asset.blade.php ENDPATH**/ ?>