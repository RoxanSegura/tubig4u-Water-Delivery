<script type="text/javascript">
    $(document).ready(function(){  
    	//$('.sidebar').toggle();
	    $(document).on( "keydown", function( event ) {
	    	url = [];
	    	url[112] = "<?php echo e(URL::route('app.dashboard')); ?>"; 
	    	url[113] = "<?php echo e(URL::route('app.customers')); ?>"; 
	    	url[114] = "<?php echo e(URL::route('app.drivers')); ?>"; 
	    	url[115] = "<?php echo e(URL::route('app.orders')); ?>";  
	    	url[116] = "<?php echo e(URL::route('app.orders.processing')); ?>";  
	    	url[117] = "<?php echo e(URL::route('app.orders.collection')); ?>"; 
	    	
	    	none = ['dashboard','report','orders.processing','orders.collection'];
    		url[192] = "<?php echo e(URL::route('app.'.$active)); ?>"; 

	    	console.log(event.which);

	    	if(event.which =='27'){
	    		$('.hideNav').click();
	    	} else if(url[event.which] != undefined){  
	    		if(event.which == 192){ 
	    			if(!none.includes('<?php echo e($active); ?>')){  
	   					document.location.href = url[event.which]+'/add'; 
	    			}
	    		} else {
	   				document.location.href = url[event.which]; 
	   			}
	   		}
		}); 
	});
</script><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/shortcuts/branch.blade.php ENDPATH**/ ?>