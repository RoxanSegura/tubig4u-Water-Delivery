<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h3>Add Information</h3>

            <?php if((session('success'))): ?>
                <p class="success"><?php echo e(session('success')); ?></p>
            <?php elseif((session('error'))): ?>
                <p class="error"><?php echo e(session('error')); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo e(URL::route('app.orders.add.save')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleInputEmail1">Choose Customer</label>
                    <select type="text" class="chosen form-control" id="exampleInputEmail1" required name="customer">
                        <?php if($customers): ?>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v->id); ?>">
                                    <?php echo e($v->address); ?> - 
                                    <?php if(is_null($v->name)): ?>
                                        no name
                                    <?php else: ?>
                                        <?php echo e($v->name); ?>

                                    <?php endif; ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <p>Customer not registered ? <a href="<?php echo e(URL::route('app.customers.add')); ?>">Click me to create new customer </a></p>
                </div>
                <!--<div class="form-group">
                    <label for="exampleInputEmail1">Choose Deliery Boy</label>
                    <select type="text" class="chosen form-control" id="exampleInputEmail1" required name="delivery">
                        <?php if($drivers): ?>
                            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <p>Driver not registered ? <a href="<?php echo e(URL::route('app.drivers.add')); ?>">Click me to create new Driver </a></p>
                     </div>-->
                <input type="hidden" name="delivery" value="0" />
                <br>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th></th> 
                                <th>Product</th>
                                <th>Price</th> 
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($products): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>  
                                        <td class="min-width">
                                            <div class="avatar" style="background-image: url(<?php echo e(URL::asset('public/img/product/'.$v->img)); ?>);"></div> 
                                        </td>
                                        <td class="new-lines"><?php echo e($v->name); ?></td>
                                        <td class="new-lines"><b>P <?php echo e(number_format($v->price,2,'.',',')); ?></b></td>
                                        <td class="">
                                            <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Qty" required name="<?php echo e($v->id); ?>" value="0">
                                        </td>
                                    </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3">
                                        <center>
                                            No Customers Yet
                                        </center>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="form-check">
                    <button class="button-default button active" aria-current="true">Save</button>
                </div>
            </form>
        </div>
    </div>

    <style type="text/css">
        .error{
            color: red;
        }
        .success{
            color:green;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraJs'); ?>
    <script type="text/javascript">
        $(".chosen").chosen();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/orders/add.blade.php ENDPATH**/ ?>