<?php $__env->startSection('content'); ?>
    <div class="border-bottom side-margins no-vertical-distance box">
        <div class="stats-wrapper">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="stat-item">
                    <div class="stat-item-value"><?php echo e($v); ?></div>
                    <div class="stat-item-title"><?php echo e(ucfirst($k)); ?></div> 
                </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/pages/dashboard/index.blade.php ENDPATH**/ ?>