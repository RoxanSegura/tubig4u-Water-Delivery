<?php $__env->startSection('content'); ?>   
	<ul class="nav nav-tabs">
		<li class="active">
			<a data-toggle="tab" href="#home">
				Processing Order
				<?php if(count($pending) > 0): ?>
					<kbd class="notif"><?php echo e(count($pending)); ?></kbd>
				<?php endif; ?>
			</a>
		</li>
		<!--<li>
			<a data-toggle="tab" href="#menu1">
				Ready for Delivery
				<?php if(count($ready) > 0): ?>
					<kbd class="notif"><?php echo e(count($ready)); ?></kbd>
				<?php endif; ?>
			</a>
		</li>-->
	</ul>

	<div class="tab-content">
		<div id="home" class="tab-pane fade in active">
            <?php if(session('error')): ?>
                <br />
                <div>
                    <small class="text-danger"><kbd class="notif">!</kbd> <?php echo e(session('error')); ?></small>
                </div>
            <?php endif; ?>
			<br>
			<div class="rowx">
        		<?php if($pending): ?>
        			<?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<div class="col-md-4x infobox pending">
						    <div class="infobox-inner"> 
						        <div class="infobox-meta"> 
					        		<small>
					        			<a href="<?php echo e(URL::route('app.orders.summary',$v->id)); ?>"><small>#<?php echo e($v->refNo); ?></small></a>

					        			<a href="<?php echo e(URL::route('app.orders.delete',$v->id)); ?>" class="decline-btn">
					        				DELETE
					        			</a>
					        			<!--<a href="<?php echo e(URL::route('app.orders.move',$v->id)); ?>" class="accept-btn">
					        				MOVE
					        			</a>-->
					        		</small>
					        		<hr>
					        		<h3> 
					        			<small>
					        				<?php echo e(App\Models\User::find($v->customer_id)->address); ?>

					        				<br>
					        			</small>
					        		</h3> 
					        		<?php $__currentLoopData = json_decode($v->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						        		<span>
						        			<small>
						        				<?php echo e($x->qty); ?> x <b><?php echo e($x->name); ?></b>
						        			</small>
						        		</span> 
					        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    <hr />
                                    <form method="get" action="<?php echo e(URL::route('app.orders.move', $v->id)); ?>">
                                            <div>
                                                <label for="exampleInputEmail1">Choose Delivery Boy</label>
                                                <?php if(!$drivers->isEmpty()): ?>
                                                    <select type="text" class="chosen form-control" required name="driver">
                                                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($driver->id); ?>" <?php echo e((time() - 60 > strtotime($driver->online)) ? 'disabled="disabled"' : null); ?> ><?php echo e($driver->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php else: ?>
                                                        <span class="text-danger">No deliver boy available</span>
                                                <?php endif; ?>
                                            </div>
                                            <br />
                                            <button type="submit" class="accept-btn">MOVE</button>
                                    </form>
						        </div>
						    </div>
						</div> 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
        	</div> 
		</div>
		<!--<div id="menu1" class="tab-pane fade">
			<br> 
			<div class="rowx"> 
        		<?php if($ready): ?>
        			<?php $__currentLoopData = $ready; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				<?php if(is_null($v->driver_id)): ?>
                			<div class="col-md-4x infobox queue">
                		<?php else: ?> 
                			<div class="infobox queue-driver">
                		<?php endif; ?>
						    <div class="infobox-inner"> 
						        <div class="infobox-meta"> 
					        		<small>
					        			<a href="<?php echo e(URL::route('app.orders.summary',$v->id)); ?>">#<?php echo e($v->refNo); ?></a> 
				        				<a href="<?php echo e(URL::route('app.orders.delete',$v->id)); ?>" class="decline-btn">
					        				DELETE
					        			</a>  
					        			<a href="<?php echo e(URL::route('app.orders.pickup',$v->id)); ?>" class="accept-btn">
					        				PICK-UP
					        			</a>
					        		</small>
					        		<hr>
					        		<h3> 
					        			<small>
					        				<?php echo e(App\Models\User::find($v->customer_id)->address); ?>

					        				<br>

        									<?php if(!is_null($v->driver_id)): ?>
        										<b>DRIVER : <?php echo e(App\Models\User::find($v->driver_id)->name); ?></b>
        									<?php endif; ?>
					        			</small>
					        		</h3> 
					        		<?php $__currentLoopData = json_decode($v->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						        		<span>
						        			<small>
						        				<?php echo e($x->qty); ?> x <b><?php echo e($x->name); ?></b>
						        			</small>
						        		</span> 
					        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        </div> 
						    </div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
            </div> 
		</div> -->
	</div>

    <style type="text/css">
    	kbd.notif{
    		background-color: red;
    		color: white;
    		border-radius: 1500px; 
    	}
    	.accept-btn{
    		background-color: green;
    		color:white;
    		font-weight: bolder;
    		text-align: center;
            padding: 7px 10px;
    		float: right; 
    	}
    	.decline-btn{
    		background-color: red;
    		color:white;
    		margin-left: 1%;
    		font-weight: bolder;
    		text-align: center;
            padding: 7px 10px;
    		float: right; 
    	}
    	.pending{
    		border-left:5px solid red;
    	}
    	.queue{
    		border-left:5px solid orange;
    	}
    	.queue-driver{
    		border-left:5px solid blue;
    	}
    	.delivered{
    		border-left:5px solid green;
    	}
    	.notdelivered{
    		border-left:5px solid violet;
    	}
    	.forcollection{
    		border-left:5px solid yellow;
    	}
    	.infobox{
            width: 99% !important;
            float: left;
            margin-right: 1%;
            padding: 10;
            height: 22em;
    	}
    	.lists{
    		text-align: left important;
    	}
    	.ordering a{
    		color: royalblue;
    	}

        .accept-btn { border: none; }
    </style>
<?php $__env->stopSection(); ?> 


<?php $__env->startSection('extraJs'); ?>
    <script type="text/javascript">
     $(".chosen").chosen();
     
     $('.nav-tabs li a').click(function() {
         let url = window.location.href.replace(/\#(.*)$/, '');
         $('#prev-url').val(url + $(this).attr('href'));
         window.location.href = url + $(this).attr('href');
//         alert($(this).attr('href'));
     });
     
     $(document).ready(function() {
         let u = window.location.href.split('#');
         if (typeof u[1] == 'undefined') {
             return;
         }
         
         let id = u[1];

         $('#prev-url').val(window.location.href);
         $('.tab-content > div.tab-pane').removeClass('active');
         $('.tab-content > div.tab-pane#' + id).addClass('active');
         $('.nav-tabs a').parent().removeClass('active');
         $('.nav-tabs a[href="#' + id + '"]').parent().addClass('active');
     });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/orders/index.blade.php ENDPATH**/ ?>