<?php $__env->startSection('body'); ?>
    <div id="root" class="page-wrapper">
        <div class="page-inner">
            
            <?php echo $__env->make('templates.components.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('templates.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main">
                <?php echo $__env->make('templates.components.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="content">
                    <div class="content-inner"> 
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

                <?php echo $__env->make('templates.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div> 
        </div>
    </div> 

    <?php if(Auth::id()): ?>
        <!-- update online status -->
        <script type="text/javascript">
            $(document).ready(()=>{
                
                setInterval(() => {

                    $.get('<?php echo e(URL::route("app.online")); ?>?user_id=<?php echo e(Auth::id()); ?>',function(res){
                        //console.log(res);
                    });

                },1000);

            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.asset', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/layout/main.blade.php ENDPATH**/ ?>