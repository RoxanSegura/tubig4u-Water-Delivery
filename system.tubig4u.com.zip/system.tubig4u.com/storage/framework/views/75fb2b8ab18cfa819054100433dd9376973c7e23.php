<script type="text/javascript">
    $(document).ready(function(){  
    	//$('.sidebar').toggle();
	    $(document).on( "keydown", function( event ) {
	    	url = [];
	    	url[112] = "<?php echo e(URL::route('app.dashboard')); ?>"; 
	    	url[113] = "<?php echo e(URL::route('app.driver.open')); ?>"; 
	    	url[114] = "<?php echo e(URL::route('app.driver.deliveries')); ?>"; 
	    	url[115] = "<?php echo e(URL::route('app.driver.collection')); ?>";   
	    	
	    	none = ['dashboard','app.driver.open','app.driver.deliveries','app.driver.collection'];
    		url[192] = "<?php echo e(URL::route('app.'.$active)); ?>"; 

	    	console.log(event.which);

	    	if(event.which =='27'){
	    		$('.hideNav').click();
	    	} else if(url[event.which] != undefined){  
	    		if(event.which == 192){ 
	    			if(!none.includes('<?php echo e($active); ?>')){  
	   					document.location.href = url[event.which]+'/add'; 
	    			}
	    		} else {
	   				document.location.href = url[event.which]; 
	   			}
	   		}
		}); 
	});
</script><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/templates/shortcuts/driver.blade.php ENDPATH**/ ?>