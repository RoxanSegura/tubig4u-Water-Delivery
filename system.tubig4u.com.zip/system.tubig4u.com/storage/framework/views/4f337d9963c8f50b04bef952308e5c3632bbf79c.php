<?php $__env->startSection('content'); ?>
    <div class="filter form-inline"> 
        <div class="form-group form-group-description">[~] - Add new <br>Displaying <?php echo e(count($data)); ?> items matching your criteria.</div> 
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Name</th> 
                    <th>Address</th>
                    <th>Plate Number</th>
                    <th>Online</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if($data): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($v->id); ?>">
                            <td class="min-width"> 
                                <div class="title-wrapper">
                                    <div class="title"><?php echo e(ucfirst($v->name)); ?></div>
                                    <div class="subtitle"><?php echo e($v->contact); ?></div>
                                </div>
                            </td> 
                            <td class="new-lines"><?php echo e($v->address); ?></td>
                            <td class="new-lines"><?php echo e($v->plateNumber); ?></td>  
                            <td class="new-lines online_status">Oflline</td>  
                            <td class="actions min-width">
                                <div class="button-dropdown">
                                    <i class="md-icon">more_horiz</i>
                                    <ul>
                                        <li><a href="<?php echo e(URL::route('app.drivers.update',$v->id)); ?>" class="action-btn">Update</a></li> 
                                        <li><a href="<?php echo e(URL::route('app.drivers.delete',$v->id)); ?>" class="action-btn">Delete</a></li> 
                                    </ul>
                                </div>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">
                            <center>
                                No Customers Yet
                            </center>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script type="text/javascript">
        $(document).ready(()=>{
            
            online = [];
            setInterval(() => {
                $.get('<?php echo e(URL::route("app.online.branch")); ?>?branch_id=<?php echo e(Auth::id()); ?>',function(res){
                    onlineNow = [];
                    for(i=0; i < res.length; i++){
                        $('#'+res[i].id+' .online_status').html('Online').addClass('onlinestat'); 

                        if(!online.includes(res[i].id)){
                            online.push(res[i].id);
                            console.log('New online was added !');
                        }

                        onlineNow.push(res[i].id);
                    }  

                    for(i=0; i < online.length; i++){ 
                        if(!onlineNow.includes(online[i])){
                            console.log('Someone is offline !');
                            $('body .online_status').html('Offline').removeClass('onlinestat');
                            online.splice(i,1);
                        }
                    }   
                });

            },1000);

        });
    </script>
    <style type="text/css"> 
        .onlinestat{
            color:yellowgreen !important;
        }
        .online_status{
            color:red;
        }
        .action-btn{
            text-align: center;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/driver/index.blade.php ENDPATH**/ ?>