<?php $__env->startSection('content'); ?>
    <div class="invoice-wrapper">
        <div class="invoice">
            <div class="invoice-header">
                <div class="invoice-logo">
                	<h3>
                		REFID : #<?php echo e($data->refNo); ?>

                	</h3>
                </div>
                <div class="invoice-description"><strong><?php echo e(date('M d, Y',strtotime($data->created_at))); ?></strong><span><?php echo e(date('h:i A',strtotime($data->created_at))); ?></span></div>
            </div>
            <div class="invoice-info">
                <div class="invoice-info-client">
                    <h4>Customer Details</h4>
                    <p>
                        <?php echo e(App\Models\User::find($data->customer_id)->name); ?> 
                        <br>
                        <br>
                        <?php echo e(App\Models\User::find($data->customer_id)->contact); ?>

                    </p>
                    <address>
                        <?php echo e(App\Models\User::find($data->customer_id)->address); ?>

                    </address>
                </div>
                <div class="invoice-info-payment">
                    <h4>Driver Details</h4>
                    <?php if(App\Models\User::find($data->driver_id)): ?>
                    <p>
                        <?php echo e(App\Models\User::find($data->driver_id)->name); ?> 
                        <br>
                        <br>
                        <?php echo e(App\Models\User::find($data->driver_id)->contact); ?>

                    </p>
                    <address>
                        <?php echo e(App\Models\User::find($data->driver_id)->address); ?>

                    </address>
                    <?php else: ?>
                        <p><small>No driver assigned</small></p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="invoice-table">
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Item</th>  
                            <th>Quantity</th>
                            <th>Unit Cost</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $total = 0;
                        ?>
                        <?php $__currentLoopData = json_decode($data->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $total = $total + ($x->price*$x->qty);
                            ?>
                            <tr>
                                <td></td>
                                <td><?php echo e($x->name); ?></td>
                                <td><?php echo e($x->qty); ?></td>
                                <td>P <?php echo e(number_format($x->price,2,'.',',')); ?></td> 
                                <td>P <?php echo e(number_format(($x->price*$x->qty),2,'.',',')); ?></td>
                            </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="invoice-summary"> 
                <div><span>Total Amount</span><strong>P <?php echo e(number_format($total,2,'.',',')); ?></strong></div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/invoice/index.blade.php ENDPATH**/ ?>