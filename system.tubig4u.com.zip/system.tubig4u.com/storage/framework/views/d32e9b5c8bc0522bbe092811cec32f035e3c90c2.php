<?php $__env->startSection('body'); ?>
    <div id="root" class="page-wrapper">
        <div class="page-empty">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.asset', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/layout/blank.blade.php ENDPATH**/ ?>