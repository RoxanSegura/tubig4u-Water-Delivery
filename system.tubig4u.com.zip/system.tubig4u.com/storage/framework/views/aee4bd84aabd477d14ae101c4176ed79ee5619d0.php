<div class="footer">
    <div class="footer-left">© <?php echo e(date('Y')); ?> Tubig App. All rights reserved.</div>
    <!-- <div class="footer-right">
        <ul> 
            <li><a>Contact</a></li>
        </ul>
    </div> -->
</div>  <?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/templates/components/footer.blade.php ENDPATH**/ ?>