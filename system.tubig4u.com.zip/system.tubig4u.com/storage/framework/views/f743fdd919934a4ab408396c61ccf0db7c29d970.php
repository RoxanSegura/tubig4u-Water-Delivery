<?php $__env->startSection('content'); ?>
    <div class="filter form-inline"> 
        <div class="form-group form-group-description">[~] - Add new <br>Displaying <?php echo e(count($data)); ?> items matching your criteria.</div> 
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Address</th>
                    <th>Name</th> 
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if($data): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="new-lines"><?php echo e($v->address); ?></td>
                            <td class="min-width"> 
                                <div class="title-wrapper">
                                    <div class="title">
                                        <?php if(is_null($v->name)): ?>
                                            null
                                        <?php else: ?>
                                            <?php echo e(ucfirst($v->name)); ?>

                                        <?php endif; ?>
                                    </div>
                                    <div class="subtitle"><?php echo e($v->contact); ?></div>
                                </div>
                            </td> 
                            <td class="actions min-width">
                                <div class="button-dropdown">
                                    <i class="md-icon">more_horiz</i>
                                    <ul>
                                        <li><a href="<?php echo e(URL::route('app.customers.update',$v->id)); ?>" class="action-btn">Update</a></li> 
                                        <li><a href="<?php echo e(URL::route('app.customers.delete',$v->id)); ?>" class="action-btn">Delete</a></li> 
                                    </ul>
                                </div>
                            </td>
                        </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">
                            <center>
                                No Customers Yet
                            </center>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <style type="text/css">
        .action-btn{
            text-align: center;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/customers/index.blade.php ENDPATH**/ ?>