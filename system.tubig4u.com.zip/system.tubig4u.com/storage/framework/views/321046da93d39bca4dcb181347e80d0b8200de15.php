<div class="page-title">
    <ul class="breadcrumbs">
        <li><a class="active" aria-current="true"><?php echo e($title); ?></a></li>
        <li><span><?php echo e($sub); ?></span></li>
    </ul>
    <h1><?php echo e($title.' '.$sub); ?></h1> 
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/templates/components/breadcrumbs.blade.php ENDPATH**/ ?>