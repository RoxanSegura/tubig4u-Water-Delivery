<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h3>Generate report</h3>

            <form method="post" action="<?php echo e(URL::route('app.report.results')); ?>">
                <?php echo e(csrf_field()); ?> 
                <div class="form-group">
                    <label for="exampleInputEmail1">Orders From</label>
                    <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Enter name" name="from">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Orders To</label>
                    <input type="date" class="form-control" id="exampleInputPassword1" placeholder="Contact Number" name="to">
                </div> 
                <?php if(Auth::user()->accountType == 'admin'): ?>
                    <div class="form-group">
                        <label for="exampleSelect1">Branch</label>
                        <select class="form-control" id="exampleSelect1" required name="branch"> 
                            <option value="all">All</option>
                            <?php if($branches): ?>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>   
                <?php elseif(Auth::user()->accountType == 'branch'): ?>
                    <input type="hidden" name="branch" value="<?php echo e(Auth::user()->id); ?>">
                <?php else: ?> 
                    <input type="hidden" name="driver" value="<?php echo e(Auth::user()->id); ?>">
                    <input type="hidden" name="branch" value="<?php echo e(Auth::user()->branch_id); ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label for="exampleSelect1">Product</label>
                    <select class="form-control" id="exampleSelect1" required name="product"> 
                        <option value="all">All</option>
                        <?php if($product): ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>   
                <div class="form-group">
                    <label for="exampleSelect1">Delivery Status</label>
                    <select class="form-control" id="exampleSelect1" required name="status">
                        <option value="all">All</option> 
                        <option value="pending">Pending</option>
                        <option value="ready">For Pickup</option>
                        <option value="pickup">On Delivery</option>
                        <option value="collection">For-Collection</option>
                        <option value="redeliver">Re-Delivery</option>
                        <option value="delivered">Delivered</option>
                    </select>
                </div>   
                <div class="form-check">
                    <button class="button-default button active" aria-current="true">Generate a report</button>
                    <a href="<?php echo e(URL::route('app.report.results')); ?>?today" class="button-success button active" aria-current="true">Todays Report</a>
                </div>
            </form>
        </div>
    </div>

    <style type="text/css">
        .error{
            color: red;
        }
        .success{
            color:green;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/report/index.blade.php ENDPATH**/ ?>