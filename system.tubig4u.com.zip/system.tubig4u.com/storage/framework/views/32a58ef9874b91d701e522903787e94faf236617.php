<div class="toolbar">
    <div class="toolbar-inner">
        <div class="logo" style="padding-top: 3em;">
            <img src="<?php echo e(URL::asset('public/img/logo.png')); ?>">
        </div>
        <ul class="top">
            <?php if(App\Services\Acl::create('addButton')): ?>
                <?php  
                    $noAddfeature = ['dashboard','report','orders.processing','orders.collection']
                ?>
                <?php if(!in_array($active,$noAddfeature)): ?> 
                    <li>
                        <a href="<?php echo e(URL::route('app.'.$active.'.add')); ?>"
                           title="<?php echo e(strtolower($active)=='orders' ? '[F10] ' : ''); ?>Create <?php echo e(ucwords($active)); ?>"
                           id="<?php echo e(strtolower($active)=='orders' ? 'add-order-btn' : ''); ?>">
                            <i class="md-icon">add</i>
                        </a>
                    </li>   
                <?php endif; ?>
            <?php endif; ?>
            <li><a onclick="$('.sidebar').toggle()" class="hideNav" title="Toggle Sidebar"><i class="md-icon">fullscreen</i></a></li>
            <li><a href="<?php echo e(URL::route('app.logout')); ?>" title="logout"><i class="md-icon">power_settings_new</i></a></li>
        </ul> 
        <ul class="bottom"></ul> 
    </div>
</div>
<?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/templates/components/aside.blade.php ENDPATH**/ ?>