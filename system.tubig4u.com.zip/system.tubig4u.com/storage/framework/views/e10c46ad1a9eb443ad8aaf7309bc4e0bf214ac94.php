<?php $__env->startSection('content'); ?>
    <div class="page-empty-content">
        <center>
            <img src="<?php echo e(URL::asset('public/img/logo.png')); ?>" class="logo">
        </center>
        <h1><?php echo e($title); ?></h1>
        <form method="post" action="<?php echo e(URL::route('app.login.verify')); ?>">
            <?php echo e(csrf_field()); ?>


            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="danger"><?php echo e($err); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php endif; ?>

            <?php if(session('error') !== null): ?>
                <p class="danger"><?php echo e(session('error')); ?></p>
            <?php endif; ?>
            
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="form-group form-group-button"> 
                <button type="submit" class="button button-primary button-right">Login</button>
            </div>
        </form> 
    </div>

    <style type="text/css">
        .danger{
            color: red;
        }
        .logo{
            width: 30%;
            margin-bottom: 5%;

        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/web/tubig/resources/views/pages/login/index.blade.php ENDPATH**/ ?>