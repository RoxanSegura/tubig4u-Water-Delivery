<?php $__env->startSection('content'); ?>     
    <ul class="nav nav-tabs">
        <!--<li class="active">
            <a data-toggle="tab" href="#home">
                For Pick-up
                <?php if(count($ready) > 0): ?>
                    <kbd class="notif"><?php echo e(count($ready)); ?></kbd>
                <?php endif; ?>
            </a>
        </li>-->
        <li class="active">
            <a data-toggle="tab" href="#menu1">
                On Delivery
                <?php if(count($ondelivery) > 0): ?>
                    <kbd class="notif"><?php echo e(count($ondelivery)); ?></kbd>
                <?php endif; ?>
            </a>
        </li>
        <li>
            <a data-toggle="tab" href="#menu2">
                For Re-delivery
                <?php if(count($redeliver) > 0): ?>
                    <kbd class="notif"><?php echo e(count($redeliver)); ?></kbd>
                <?php endif; ?>
            </a>
        </li> 
        <li>
            <a data-toggle="tab" href="#menu3">
                For Collection
                <?php if(count($collection) > 0): ?>
                    <kbd class="notif"><?php echo e(count($collection)); ?></kbd>
                <?php endif; ?>
            </a>
        </li> 
    </ul>

    <div class="tab-content">
        <div id="home" class="tab-pane fade in"> 
            <br>
            <div class="rowx">
                <?php if($ready): ?>
                    <?php $__currentLoopData = $ready; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="<?php echo e(URL::route('app.orders.summary',$v->id)); ?>"><small>#<?php echo e($v->refNo); ?></small></a> 
                                        <span style="float: right;"><?php echo e($v->updated_at->diffForHumans()); ?></span>  
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            <?php echo e(App\Models\User::find($v->customer_id)->address); ?>

                                            <br>
                                            <?php if(!is_null($v->driver_id)): ?>
                                                <b>Delivery Boy :</b><br>
                                                <?php echo e(App\Models\User::find($v->driver_id)->name); ?>

                                            <?php endif; ?>
                                        </small>
                                    </h3> 
                                    <?php $__currentLoopData = json_decode($v->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span>
                                            <small>
                                                <?php echo e($x->qty); ?> x <b><?php echo e($x->name); ?></b>
                                            </small>
                                        </span> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div> 
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> 
        </div> 
        <div id="menu1" class="tab-pane fade in active"> 
            <br>
            <div class="rowx">
                <?php if($ondelivery): ?>
                    <?php $__currentLoopData = $ondelivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4x infobox queue">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="<?php echo e(URL::route('app.orders.summary',$v->id)); ?>"><small>#<?php echo e($v->refNo); ?></small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?> 
                                        <a href="<?php echo e(URL::route('app.drivers.orders.updatestatus',[$v->id,'redeliver'])); ?>" class="decline-btn">
                                            RE-DELIVERY
                                        </a> 
                                        <a href="<?php echo e(URL::route('app.drivers.orders.updatestatus',[$v->id,'collection'])); ?>" class="decline-btn">
                                            FOR COLLECTION
                                        </a> 
                                        <!--<a href="<?php echo e(URL::route('app.drivers.orders.updatestatus',[$v->id,'delivered'])); ?>" class="accept-btn">
                                            DELIVERED
                                        </a>--> 
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            <?php echo e(App\Models\User::find($v->customer_id)->address); ?>

                                            <br>
                                            <?php if(!is_null($v->driver_id)): ?>
                                                <b>Delivery Boy :</b><br>
                                                <?php echo e(App\Models\User::find($v->driver_id)->name); ?>

                                            <?php endif; ?>
                                        </small>
                                    </h3> 
                                    <?php $__currentLoopData = json_decode($v->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span>
                                            <small>
                                                <?php echo e($x->qty); ?> x <b><?php echo e($x->name); ?></b>
                                            </small>
                                        </span> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div> 
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> 
        </div> 
        <div id="menu2" class="tab-pane fade in"> 
            <br>
            <div class="rowx">
                <?php if($redeliver): ?>
                    <?php $__currentLoopData = $redeliver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="<?php echo e(URL::route('app.orders.summary',$v->id)); ?>"><small>#<?php echo e($v->refNo); ?></small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?> 
                                        <span style="float: right;"><?php echo e($v->updated_at->diffForHumans()); ?></span> 
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            <?php echo e(App\Models\User::find($v->customer_id)->address); ?>

                                            <br>
                                            <?php if(!is_null($v->driver_id)): ?>
                                                <b>Delivery Boy :</b><br>
                                                <?php echo e(App\Models\User::find($v->driver_id)->name); ?>

                                            <?php endif; ?>
                                        </small>
                                    </h3> 
                                    <?php $__currentLoopData = json_decode($v->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span>
                                            <small>
                                                <?php echo e($x->qty); ?> x <b><?php echo e($x->name); ?></b>
                                            </small>
                                        </span> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div> 
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> 
        </div>  
        <div id="menu3" class="tab-pane fade in"> 
            <br>
            <div class="rowx">
                <?php if($collection): ?>
                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4x infobox pending">
                            <div class="infobox-inner"> 
                                <div class="infobox-meta"> 
                                    <small>
                                        <a href="<?php echo e(URL::route('app.orders.summary',$v->id)); ?>"><small>#<?php echo e($v->refNo); ?></small></a>
                                        <?php
                                            $datetime1 = new DateTime(date('Y-m-d h:m:i',strtotime($v->updated_at)));
                                            $datetime2 = new DateTime(date('Y-m-d h:m:i'));
                                            $interval = $datetime1->diff($datetime2); 
                                        ?> 
                                        <a href="<?php echo e(URL::route('app.drivers.orders.updatestatus',[$v->id,'delivered'])); ?>" class="accept-btn">
                                            COLLECTED
                                        </a> 
    
                                    </small>
                                    <hr>
                                    <h3> 
                                        <small>
                                            <?php echo e(App\Models\User::find($v->customer_id)->address); ?>

                                            <br>
                                            <?php if(!is_null($v->driver_id)): ?>
                                                <b>Delivery Boy :</b><br>
                                                <?php echo e(App\Models\User::find($v->driver_id)->name); ?>

                                            <?php endif; ?>
                                        </small>
                                    </h3> 
                                    <?php $__currentLoopData = json_decode($v->orders); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span>
                                            <small>
                                                <?php echo e($x->qty); ?> x <b><?php echo e($x->name); ?></b>
                                            </small>
                                        </span> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div> 
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> 
        </div> 
    </div>

    <style type="text/css">
        kbd.notif{
            background-color: red;
            color: white;
            border-radius: 1500px; 
        }
        .accept-btn{
            background-color: green;
            color:white;
            font-weight: bolder;
            text-align: center;
            padding: 7px 10px;
            float: right; 
        }
        .decline-btn{
            background-color: red;
            color:white;
            margin-left: 1%;
            font-weight: bolder;
            text-align: center;
            padding: 7px 10px;
            float: right; 
        }
        .pending{
            border-left:5px solid red;
        }
        .queue{
            border-left:5px solid orange;
        }
        .queue-driver{
            border-left:5px solid blue;
        }
        .delivered{
            border-left:5px solid green;
        }
        .notdelivered{
            border-left:5px solid violet;
        }
        .forcollection{
            border-left:5px solid yellow;
        }
        .infobox{
            width: 99% !important;
            float: left;
            margin-right: 1%;
            padding: 10;
            height: 12em;
        }
        .lists{
            text-align: left important;
        }
        .ordering a{
            color: royalblue;
        }
    </style>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('extraJs'); ?>
    <script type="text/javascript">
     $('.nav-tabs li a').click(function() {
         let url = window.location.href.replace(/\#(.*)$/, '');
         window.location.href = url + $(this).attr('href');
         let u = '?prev_url=' + window.location.href + '#' + $(this).attr('href');
         
         $('.accept-btn').each(function() {
             $(this).attr('href', $(this).attr('href').replace(/\?(.*)/, '') + u);
         });
         
         $('.decline-btn').each(function() {
             $(this).attr('href', $(this).attr('href').replace(/\?(.*)/, '') + u);
         });
         
//         alert($(this).attr('href'));
     });

     $(document).ready(function() {
         let u = window.location.href.split('#');
         
         if (typeof u[1] == 'undefined') {
             return;
         }
         
         let id = u[1];

         let url = '?prev_url=' + window.location.href + '#' + id;
         $('.accept-btn').each(function() {
             $(this).attr('href', $(this).attr('href') + url);
         });
         
         $('.decline-btn').each(function() {
             $(this).attr('href', $(this).attr('href') + url);
         });
         
         $('.tab-content > div.tab-pane').removeClass('active');
         $('.tab-content > div.tab-pane#' + id).addClass('active');
         $('.nav-tabs a').parent().removeClass('active');
         $('.nav-tabs a[href="#' + id + '"]').parent().addClass('active');
     });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/orders/driver/open.blade.php ENDPATH**/ ?>