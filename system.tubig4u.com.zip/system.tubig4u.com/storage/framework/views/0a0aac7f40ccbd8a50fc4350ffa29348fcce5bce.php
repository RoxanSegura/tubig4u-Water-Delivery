<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <h3>Add Information</h3>

            <?php if((session('success'))): ?>
                <p class="success"><?php echo e(session('success')); ?></p>
            <?php elseif((session('error'))): ?>
                <p class="error"><?php echo e(session('error')); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo e(URL::route('app.branch.add.save')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="exampleInputEmail1">Branch Name</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter name" required name="name">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Contact</label>
                    <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Contact Number" required name="contact">
                </div>
                <div class="form-group">
                    <label for="exampleTextarea">Address</label>
                    <textarea class="form-control" id="exampleTextarea" rows="15" required name="address"></textarea>
                </div> 
                <div class="form-group">
                    <label for="exampleInputPassword1">Username</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Usernmae" required name="username">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required name="password">
                </div>  
                <div class="form-check">
                    <button class="button-default button active" aria-current="true">Save</button>
                </div>
            </form>
        </div>
    </div>

    <style type="text/css">
        .error{
            color: red;
        }
        .success{
            color:green;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iiqzu4unhuyq/public_html/system.tubig4u.com/resources/views/pages/branch/add.blade.php ENDPATH**/ ?>