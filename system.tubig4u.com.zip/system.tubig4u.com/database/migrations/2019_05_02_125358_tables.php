<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Tables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name')->nullable(); 
            $table->string('username'); 
            $table->string('password'); 
            $table->string('contact')->nullable();
            $table->string('address')->nullable();
            $table->string('plateNumber')->nullable(); 
            $table->string('accountType');
            $table->integer('status'); 
            $table->timestamps();
        });

        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name'); 
            $table->string('price');  
            $table->integer('status'); 
            $table->timestamps();
        });

        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('id'); 
            $table->string('refNo');  
            $table->integer('customer_id'); 
            $table->integer('driver_id')->nullable(); 
            $table->longText('orders')->nullable();   
            $table->string('orderStatus');  
            $table->integer('status'); 
            $table->timestamps();
        });
         
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
