-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 31, 2019 at 04:34 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autoaidp_tubig`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_05_02_125358_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `refNo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `orders` longtext COLLATE utf8mb4_unicode_ci,
  `orderStatus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `refNo`, `customer_id`, `branch_id`, `driver_id`, `orders`, `orderStatus`, `status`, `created_at`, `updated_at`) VALUES
(4, 'ZNBBC', 14, 9, 15, '[{\"id\":5,\"name\":\"5 gallons - Slim\",\"price\":\"65\",\"qty\":\"3\",\"total\":195}]', 'delivered', 1, '2019-05-30 15:35:01', '2019-05-30 17:52:20'),
(5, 'AKGSL', 14, 9, 15, '[{\"id\":5,\"name\":\"5 gallons - Slim\",\"price\":\"65\",\"qty\":\"3\",\"total\":195}]', 'delivered', 1, '2019-05-30 15:35:01', '2019-05-30 17:52:29'),
(6, 'PASOF', 14, 9, 15, '[{\"id\":5,\"name\":\"5 gallons - Slim\",\"price\":\"65\",\"qty\":\"3\",\"total\":195}]', 'delivered', 1, '2019-05-30 15:35:01', '2019-05-30 17:26:44');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` longtext COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `img`, `status`, `created_at`, `updated_at`) VALUES
(5, '5 gallons - Slim', '65', '26baf068480a9de2d8d51b258f1b0789.jpeg', 1, '2019-05-30 12:32:08', '2019-05-30 12:32:08'),
(6, '5 gallons - Round', '45', '00eca24f-b0e5-4e70-b4e4-6958eeee70ab_1.461f602c7723e5e4604f5c3733975ea5.jpeg', 1, '2019-05-30 12:32:52', '2019-05-30 12:44:03'),
(7, 'asd', '123', '26baf068480a9de2d8d51b258f1b0789.jpeg', 0, '2019-05-30 12:33:32', '2019-05-30 12:33:36'),
(8, '5 gallons - Slim', '65', NULL, 0, '2019-05-30 12:38:11', '2019-05-30 12:38:56'),
(9, '5 gallons - Slim', '65', NULL, 0, '2019-05-30 12:38:24', '2019-05-30 12:38:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plateNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `contact`, `address`, `plateNumber`, `accountType`, `branch_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Rhomeo Hildawa', 'admin', '$2y$10$v1gpq54PHirMZFmxShyQ6OMugpID1v0QR4ZdQMOdmicmpc/EGJouO', NULL, NULL, NULL, 'admin', NULL, 1, '2019-05-02 09:35:06', '2019-05-30 12:29:02'),
(9, 'Manila', 'manila', '$2y$10$vpTmm5FHjQ4MIV9mwSd5Ne3QJ4AGado9wlZRwKKv0nfrNit6Ja5Nu', '09993439934', 'Manila, Philippines', NULL, 'branch', NULL, 1, '2019-05-30 11:42:23', '2019-05-30 14:23:06'),
(10, 'Makati', 'makati', '$2y$10$SEwxQC6.GRl3.J8Z2VSZY.E6f.TlpcPqS8GefB1T3E6dhgO2zvej2', '09342924920', 'Makati, Philippines', NULL, 'branch', NULL, 1, '2019-05-30 11:44:45', '2019-05-30 11:44:45'),
(11, 'Pasig', 'pasig', '$2y$10$v1gpq54PHirMZFmxShyQ6OMugpID1v0QR4ZdQMOdmicmpc/EGJouO', '09535399531', 'Pasig, Philippines', NULL, 'branch', NULL, 1, '2019-05-30 11:45:09', '2019-05-30 11:45:09'),
(14, 'Kenneth', NULL, NULL, '0913123', 'Manila', NULL, 'customer', 9, 1, '2019-05-30 14:30:51', '2019-05-30 14:30:51'),
(15, 'Rhomeo Hildawa', 'rhomeo', '$2y$10$ohTtdSeIhqj4pbXS2H4Hi.IV6//72ima24yjNcmVrdS99pW6YD9BG', '0999999999', 'Manil', 'GSW 666', 'driver', 9, 1, '2019-05-30 14:38:41', '2019-05-30 16:35:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
